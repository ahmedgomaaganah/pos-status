/*
 * Service Worker - للتثبيت والتشغيل الكامل أوفلاين على المضيفات التي تدعم HTTPS
 * (مثال: GitHub Pages / Netlify / Vercel)
 * ملاحظة: بلوجر لا يدعم رفع ملفات مستقلة، لذا هذا الملف اختياري للاستضافة المناسبة.
 */
const CACHE = 'pos-cache-v1';
const ASSETS = ['index.html', 'config.js', 'manifest.json'];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  // لا نتدخل في طلبات السيرفر (Google Apps Script) ولا في CDN الخارجية
  if (url.origin !== location.origin) return;
  if (url.pathname.endsWith('.js') || url.pathname.endsWith('.css')) {
    e.respondWith(
      caches.match(e.request).then((cached) => {
        const fetched = fetch(e.request).then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
          return res;
        });
        return cached || fetched;
      })
    );
  }
});
