﻿/**
 * ============================================================
 * نظام نقاط البيع المتكامل (POS) - أدوات منزلية
 * Google Apps Script - Backend
 * ============================================================
 *
 * لإعداد هذا الكود:
 * 1. افتح ورقة Google Sheets جديدة
 * 2. من القائمة: الأدوات (Tools) ← محرر البرامج النصية (Script Editor)
 * 3. الصق هذا الكود كاملاً مكان Code.gs
 * 4. احفظ وشغّل الدالة setupSheets() مرة واحدة (الترخيص الأول)
 * 5. انشر (Deploy) ← نشر جديد ← تطبيق ويب
 *    - التنفيذ بصفة: أنا (Me)
 *    - من يمكنه الوصول: أي شخص لديه الرابط (Anyone)
 * 6. انسخ رابط الويب وضعه في ملف config.js على الجانب HTML
 * ============================================================
 */

// ====== أسماء الأوراق ======
var SHEET_USERS = 'المستخدمين';
var SHEET_PRODUCTS = 'المنتجات';
var SHEET_SALES = 'المبيعات';
var SHEET_SALE_ITEMS = 'بنود المبيعات';
var SHEET_CUSTOMERS = 'العملاء';
var SHEET_CREDIT_DETAILS = 'تفاصيل الآجل';
var SHEET_PAYMENTS = 'سجل تسديد الآجل';
var SHEET_SUPPLIERS = 'الموردين';
var SHEET_SUPPLIER_PAYMENTS = 'سجل تسديد الموردين';
var SHEET_PURCHASES = 'المشتريات';
var SHEET_PURCHASE_ITEMS = 'بنود المشتريات';
var SHEET_PURCHASE_RETURNS = 'مرتجع المشتريات';
var SHEET_RETURNS = 'المرتجعات';
var SHEET_CATEGORIES = 'الأقسام';
var SHEET_SETTINGS = 'الإعدادات';
var SHEET_ARCHIVE = 'الأرشيف';
var SHEET_EXPENSES = 'المصاريف';
var SHEET_OPLOG = 'سجل النسخ الاحتياطي';

var ALLOWED_ORIGINS = ['*'];

/**
 * ====== إنشاء الأوراق والبيانات الأولية ======
 */
function setupSheets() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  var sheets = [
    [SHEET_USERS, BACKUP_HEADERS.users, [['المدير', 'admin123', 'مدير', 'ALL']]],
    [SHEET_PRODUCTS, BACKUP_HEADERS.products, []],
    [SHEET_SALES, BACKUP_HEADERS.sales, []],
    [SHEET_SALE_ITEMS, BACKUP_HEADERS.saleItems, []],
    [SHEET_CUSTOMERS, BACKUP_HEADERS.customers, []],
    [SHEET_CREDIT_DETAILS, BACKUP_HEADERS.creditDetails, []],
    [SHEET_PAYMENTS, BACKUP_HEADERS.payments, []],
    [SHEET_SUPPLIERS, BACKUP_HEADERS.suppliers, []],
    [SHEET_SUPPLIER_PAYMENTS, BACKUP_HEADERS.supplierPayments, []],
    [SHEET_PURCHASES, BACKUP_HEADERS.purchases, []],
    [SHEET_PURCHASE_ITEMS, BACKUP_HEADERS.purchaseItems, []],
    [SHEET_PURCHASE_RETURNS, BACKUP_HEADERS.purchaseReturns, []],
    [SHEET_RETURNS, BACKUP_HEADERS.returns, []],
    [SHEET_CATEGORIES, ['اسم القسم'], [['أدوات مطبخ'], ['أجهزة كهربائية'], ['أدوات تنظيف'], ['أدوات حدائق'], ['إضاءة'], ['أثاث منزلي'], ['مفروشات'], ['أدوات سباكة'], ['دهانات'], ['أدوات يدوية']]],
    [SHEET_SETTINGS, BACKUP_HEADERS.settings, [['نسبة الضريبة', '10'], ['اسم المتجر', 'متجر الأدوات المنزلية'], ['عنوان المتجر', ''], ['هاتف المتجر', ''], ['كل يوم ضريبة', 'FALSE']]],
    [SHEET_ARCHIVE, BACKUP_HEADERS.archive, []],
    [SHEET_EXPENSES, BACKUP_HEADERS.expenses, []],
    [SHEET_OPLOG, ['الوقت', 'المستخدم', 'العملية', 'البيانات', 'معرف'], []]
  ];

  sheets.forEach(function (s) {
    if (ss.getSheetByName(s[0]) == null) {
      var sh = ss.insertSheet(s[0]);
      appendRow(sh, s[1]);
      if (s[2]) {
        s[2].forEach(function (r) { appendRow(sh, r); });
      }
    }
  });

  // ترقية تلقائية: محاذاة صف العناوين (الترويسة) مع الأعمدة الفعلية للبيانات في كل الأوراق
  repairAllHeaders(ss);

  return 'تم إنشاء جميع الأوراق بنجاح';
}

/**
 * محاذاة صف العناوين مع الأعمدة الفعلية للبيانات في ورقة معينة
 * (تصحح العناوين المندمجة/الناقصة مثل اندماج معرف المنتج/الاسم/الباركود في عمود واحد)
 */
function repairSheetHeaders(sh, headers) {
  if (sh == null) return;
  var lc = sh.getLastColumn();
  var exists = lc > 0;
  var same = true;
  if (exists) {
    try {
      var cur = sh.getRange(1, 1, 1, Math.min(lc, headers.length)).getValues()[0];
      for (var j = 0; j < cur.length; j++) if (String(cur[j]) !== headers[j]) { same = false; break; }
      if (lc < headers.length) same = false;
    } catch (err) { same = false; }
  } else {
    same = false;
  }
  if (same) return;
  var width = Math.max(headers.length, lc);
  var row = [];
  for (var i = 0; i < width; i++) row.push((i < headers.length) ? headers[i] : '');
  sh.getRange(1, 1, 1, width).setValues([row]);
}

/**
 * محاذاة صف العناوين في جميع أوراق النظام دفعة واحدة
 */
function repairAllHeaders(ss) {
  var map = [
    [SHEET_USERS, BACKUP_HEADERS.users],
    [SHEET_PRODUCTS, BACKUP_HEADERS.products],
    [SHEET_SALES, BACKUP_HEADERS.sales],
    [SHEET_SALE_ITEMS, BACKUP_HEADERS.saleItems],
    [SHEET_CUSTOMERS, BACKUP_HEADERS.customers],
    [SHEET_CREDIT_DETAILS, BACKUP_HEADERS.creditDetails],
    [SHEET_PAYMENTS, BACKUP_HEADERS.payments],
    [SHEET_SUPPLIERS, BACKUP_HEADERS.suppliers],
    [SHEET_SUPPLIER_PAYMENTS, BACKUP_HEADERS.supplierPayments],
    [SHEET_PURCHASES, BACKUP_HEADERS.purchases],
    [SHEET_PURCHASE_ITEMS, BACKUP_HEADERS.purchaseItems],
    [SHEET_PURCHASE_RETURNS, BACKUP_HEADERS.purchaseReturns],
    [SHEET_RETURNS, BACKUP_HEADERS.returns],
    [SHEET_CATEGORIES, ['اسم القسم']],
    [SHEET_SETTINGS, BACKUP_HEADERS.settings],
    [SHEET_EXPENSES, BACKUP_HEADERS.expenses]
  ];
  map.forEach(function (m) {
    var sh = ss.getSheetByName(m[0]);
    if (sh != null) repairSheetHeaders(sh, m[1]);
  });
  var arch = ss.getSheetByName(SHEET_ARCHIVE);
  if (arch != null) repairSheetHeaders(arch, BACKUP_HEADERS.archive);
}

function appendRow(sheet, data) {
  sheet.appendRow(data);
}

// حفظ الحالة / البيانات الثابتة بين الاستدعاءات
var cache = CacheService.getScriptCache();

/**
 * ====== نقطة الدخول الرئيسية (Web App) ======
 */
function doPost(e) {
  return handleRequest(e);
}

function doGet(e) {
  return handleRequest(e);
}

function handleRequest(e) {
  try {
    var body = {};
    if (e && e.postData && e.postData.contents) {
      try { body = JSON.parse(e.postData.contents); } catch (err) { body = {}; }
    }
    if (e && e.parameter) {
      Object.keys(e.parameter).forEach(function (k) { body[k] = e.parameter[k]; });
    }

    var action = body.action || body.type || '';
    var user = body.user || body.username || '';
    var pass = body.pass || body.password || '';
    user = String(user);
    pass = String(pass);

    // التحقق من تسجيل الدخول لجميع العمليات ما عدا تسجيل الدخول نفسه
    var auth = null;
    if (action !== 'LOGIN') {
      auth = authenticate(user, pass);
      if (!auth.ok) return jsonError('غير مصرح به - بيانات الدخول غير صحيحة');
    }

    // ترقية تلقائية: محاذاة صف العناوين مع الأعمدة الفعلية للبيانات (مرة واحدة عند أول طلب بعد التحديث)
    repairAllHeaders(SpreadsheetApp.getActiveSpreadsheet());

    switch (action) {
      case 'LOGIN': return handleLogin(body);
      case 'GET_PRODUCTS': return handleGetProducts(body);
      case 'ADD_PRODUCT': return handleAddProduct(body, auth);
      case 'UPDATE_PRODUCT': return handleUpdateProduct(body, auth);
      case 'DELETE_PRODUCT': return handleDeleteProduct(body, auth);
      case 'ADD_CATEGORY': return handleAddCategory(body);
      case 'GET_CATEGORIES': return handleGetCategories(body);
      case 'CREATE_SALE': return handleCreateSale(body, auth);
      case 'DELETE_SALE': return handleDeleteSale(body, auth);
      case 'DELETE_SALE_ITEM': return handleDeleteSaleItem(body, auth);
      case 'GET_RETURNS': return handleGetReturns(body, auth);
      case 'DELETE_RETURN': return handleDeleteReturn(body, auth);
      case 'RETURN_SALE': return handleReturnSale(body, auth);
      case 'GET_SALES': return handleGetSales(body, auth);
      case 'GET_SALE_ITEMS': return handleGetSaleItems(body);
      case 'GET_CUSTOMERS': return handleGetCustomers(body);
      case 'ADD_CUSTOMER': return handleAddCustomer(body);
      case 'UPDATE_CUSTOMER': return handleUpdateCustomer(body);
      case 'DELETE_CUSTOMER': return handleDeleteCustomer(body);
      case 'ADD_PAYMENT': return handleAddPayment(body);
      case 'GET_PAYMENTS': return handleGetPayments(body);
      case 'GET_SUPPLIERS': return handleGetSuppliers(body);
      case 'GET_SUPPLIER_PAYMENTS': return handleGetSupplierPayments(body);
      case 'ADD_SUPPLIER_DEBT': return handleSupplierPayment(body, auth, 'دين');
      case 'SETTLE_SUPPLIER_DEBT': return handleSupplierPayment(body, auth, 'تسديد');
      case 'ADD_SUPPLIER': return handleAddSupplier(body);
      case 'UPDATE_SUPPLIER': return handleUpdateSupplier(body);
      case 'DELETE_SUPPLIER': return handleDeleteSupplier(body);
      case 'CREATE_PURCHASE': return handleCreatePurchase(body, auth);
      case 'GET_PURCHASES': return handleGetPurchases(body);
      case 'GET_PURCHASE_ITEMS': return handleGetPurchaseItems(body);
      case 'SETTLE_PURCHASE': return handleSettlePurchase(body, auth);
      case 'CREATE_PURCHASE_RETURN': return handleCreatePurchaseReturn(body, auth);
      case 'GET_PURCHASE_RETURNS': return handleGetPurchaseReturns(body, auth);
      case 'GET_REPORT': return handleGetReport(body, auth);
      case 'GET_DEBT_REPORT': return handleGetDebtReport(body, auth);
      case 'GET_USERS': return handleGetUsers(body, auth);
      case 'ADD_USER': return handleAddUser(body, auth);
      case 'UPDATE_USER': return handleUpdateUser(body, auth);
      case 'DELETE_USER': return handleDeleteUser(body, auth);
      case 'GET_SETTINGS': return handleGetSettings(body);
      case 'UPDATE_SETTINGS': return handleUpdateSettings(body, auth);
      case 'GET_CREDIT_DETAILS': return handleGetCreditDetails(body, auth);
      case 'GET_DASHBOARD': return handleGetDashboard(body);
      case 'GET_ALL_DATA': return handleGetAllData(body, auth);
      case 'BACKUP_EXPORT': return handleBackupExport(body, auth);
      case 'BACKUP_IMPORT': return handleBackupImport(body, auth);
      case 'BACKUP_OP': return handleBackupOp(body, auth);
      case 'BACKUP_APPLY': return handleBackupApply(body, auth);
      case 'BACKUP_QUERY': return handleBackupQuery(body, auth);
      case 'SYNC_MIRROR': return handleSyncMirror(body, auth);
      case 'GET_ARCHIVE': return handleGetArchive(body, auth);
      case 'ARCHIVE_SALE': return handleArchiveSale(body, auth);
      case 'DELETE_ARCHIVE': return handleDeleteArchive(body, auth);
      case 'ADD_EXPENSE': return handleAddExpense(body, auth);
      case 'GET_EXPENSES': return handleGetExpenses(body, auth);
      case 'DELETE_EXPENSE': return handleDeleteExpense(body, auth);
      default:
        return jsonError('إجراء غير معروف: ' + action);
    }
  } catch (err) {
    Logger.log(err.toString());
    return jsonError('خطأ في السيرفر: ' + err.toString());
  }
}

function jsonError(msg) {
  return ContentService.createTextOutput(JSON.stringify({ ok: false, error: msg }))
    .setMimeType(ContentService.MimeType.JSON);
}
function jsonOk(data) {
  return ContentService.createTextOutput(JSON.stringify({ ok: true, data: data }))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * ====== المصادقة والصلاحيات ======
 */
function authenticate(username, password) {
  username = String(username || '');
  password = String(password || '');
  var sh = getSheet(SHEET_USERS);
  var rows = readSheet(sh);
  for (var i = 1; i < rows.length; i++) {
    var u = String(rows[i][0] || '');
    var p = String(rows[i][1] || '');
    if (u === username && p === password) {
      return { ok: true, name: u, role: String(rows[i][2] || ''), permissions: String(rows[i][3] || '') };
    }
  }
  return { ok: false };
}

function handleLogin(body) {
  var auth = authenticate(body.user || body.username, body.pass || body.password);
  if (!auth.ok) return jsonError('اسم المستخدم أو كلمة المرور غير صحيحة');
  return jsonOk({ name: auth.name, role: auth.role, permissions: (auth.permissions || '').split(',') });
}

function hasPermission(userCheck, perm) {
  if (!userCheck.role) return false;
  if (userCheck.role === 'مدير') return true;
  // الكاشير ممنوع من سعر التكلفة دائماً (حتى لو منح صراحة)
  if (perm === 'costs' && userCheck.role === 'كاشير') return false;
  var perms = (userCheck.permissions || '').split(',');
  // الكاشير يحتفظ بأساسيات البيع والمخزون (بما يتوافق مع واجهة الكاشير)
  if (userCheck.role === 'كاشير') perms = perms.concat(['sales', 'products']);
  if (perms.indexOf(perm) >= 0 || perms.indexOf('ALL') >= 0) return true;
  // ربط الصلاحيات التفصيلية بالصلاحيات الأساسية (كامل التوافق مع القيم المحفوظة)
  var map = {
    'returns': ['sales'], 'salesDelete': ['sales', 'reports'],
    'payments': ['customers'], 'purchaseReturns': ['purchases'],
    'costs': ['products']
  };
  if (map[perm]) {
    for (var i = 0; i < map[perm].length; i++) {
      if (perms.indexOf(map[perm][i]) >= 0) return true;
    }
  }
  return false;
}

/**
 * ====== أدوات مساعدة للأوراق ======
 */
function getSheet(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (sh == null) { setupSheets(); sh = ss.getSheetByName(name); }
  return sh;
}

function readSheet(sh) {
  if (sh.getLastRow() < 1) return [];
  return sh.getRange(1, 1, sh.getLastRow(), sh.getLastColumn()).getValues();
}

function clearSheet(sh) {
  if (sh.getLastRow() >= 1) sh.getRange(1, 1, sh.getLastRow(), sh.getLastColumn()).clearContent();
}

function setHeaders(sh, headers) {
  var r = sh.getRange(1, 1, 1, headers.length);
  r.setValues([headers]);
  r.setFontWeight('bold');
  r.setBackground('#e8eaf6');
}

function addRow(sh, row) {
  sh.appendRow(row);
}

// كتابة العناوين + البيانات دفعة واحدة في كتل صغيرة (أسرع وأقل قابلية للفشل من
// appendRow لكل صف؛ يُقيُّها من أخطاء المهلة في النسخة الكبيرة)
function writeSheetData(sh, headers, rows) {
  var out = [headers.slice()];
  var maxC = headers.length;
  for (var i = 0; i < rows.length; i++) {
    var r = rows[i];
    if (!Array.isArray(r)) continue;
    var row = r.slice(0, maxC);
    while (row.length < maxC) row.push('');
    out.push(row);
  }
  setHeaders(sh, headers);
  if (out.length > 1) {
    var CH = 150;
    for (var st = 1; st < out.length; st += CH) {
      var chunk = out.slice(st, st + CH);
      sh.getRange(st + 1, 1, chunk.length, maxC).setValues(chunk);
    }
  }
  // مسح أي صفوف قديمة متبقية أسفل البيانات الجديدة (حالة الحذف/التقصير)
  var exist = sh.getLastRow();
  if (exist > out.length) sh.getRange(out.length + 1, 1, exist - out.length, Math.max(maxC, sh.getLastColumn())).clearContent();
}

function rowsToObjects(rows, headers) {
  var result = [];
  for (var i = 1; i < rows.length; i++) {
    var obj = {};
    var hasData = false;
    for (var c = 0; c < headers.length; c++) {
      obj[headers[c]] = rows[i][c] !== undefined ? rows[i][c] : '';
      if (rows[i][c] !== undefined && rows[i][c] !== '') hasData = true;
    }
    if (hasData) result.push(obj);
  }
  return result;
}

/**
 * ====== المنتجات ======
 */
function handleGetProducts() {
  var sh = getSheet(SHEET_PRODUCTS);
  var rows = readSheet(sh);
  var headers = ['id', 'name', 'barcode', 'category', 'sellPrice', 'wholesalePrice', 'semiPrice', 'costPrice', 'quantity', 'minQuantity', 'addedDate', 'status'];
  var products = rowsToObjects(rows, headers);
  products.forEach(function (p) {
    // فرض معرف المنتج والباركود كنص دائماً (حتى لو أُدخلا كأرقام في الشيت)
    p.id = String(p.id);
    p.barcode = String(p.barcode);
    for (var k in p) {
      var v = p[k];
      if (typeof v === 'string' && v !== '' && !isNaN(Number(v)) && k !== 'name' && k !== 'id' && k !== 'category' && k !== 'barcode' && k !== 'addedDate' && k !== 'status') {
        p[k] = Number(v);
      }
    }
    p.quantity = Number(p.quantity) || 0;
    p.lowStock = p.quantity <= (Number(p.minQuantity) || 0);
  });
  return jsonOk(products);
}

function handleAddProduct(body, userCheck) {
  if (!hasPermission(userCheck, 'products')) return jsonError('لا تملك صلاحية إدارة المنتجات');
  var sh = getSheet(SHEET_PRODUCTS);
  var id = body.id && body.id !== '' ? body.id.toString() : 'P' + Date.now().toString().slice(-6);
  var barcode = (body.barcode && body.barcode !== '') ? body.barcode.toString() : id;

  // متسامح: إعادة رفع نفس المنتج (ID مكرر) تحدّث صفه بدل رفضه حتى لا تعلق
  // قائمة المزامنة برسالة «معرف المنتج موجود مسبقاً» عند إعادة محاولة بعد نجاح الرفع.
  var rows = readSheet(sh);
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === id) {
      // طلب «أضف الكمية للموجود» (جمع على المخزون الحالي بدل الاستبدال)
      // مع حساب متوسط سعر التكلفة: (كمية قديمة × تكلفة قديمة + كمية جديدة × تكلفة جديدة) ÷ الكمية الإجمالية
      // وتحديث أسعار البيع والجملة ونصف الجملة إلى القيم الجديدة إذا أُدخلت
      if (body.addToExisting === true || body.addToExisting === 'true') {
        var oldQty = Number(rows[i][8]) || 0;
        var newQty = Number(body.quantity) || 0;
        var oldCost = Number(rows[i][7]) || 0;
        var newCost = Number(body.costPrice) || 0;
        var mergedQty = oldQty + newQty;
        var avgCost = mergedQty > 0 ? ((oldQty * oldCost) + (newQty * newCost)) / mergedQty : newCost;
        sh.getRange(i + 1, 8).setValue(Math.round(avgCost * 100) / 100);
        sh.getRange(i + 1, 9).setValue(mergedQty);
        if ((Number(body.sellPrice) || 0) > 0) sh.getRange(i + 1, 5).setValue(Number(body.sellPrice) || 0);
        if ((Number(body.wholesalePrice) || 0) > 0) sh.getRange(i + 1, 6).setValue(Number(body.wholesalePrice) || 0);
        if ((Number(body.semiPrice) || 0) > 0) sh.getRange(i + 1, 7).setValue(Number(body.semiPrice) || 0);
        return jsonOk({ id: id, updated: true, stockAdded: true });
      }
      sh.getRange(i + 1, 2, 1, 11).setValues([[
        body.name, barcode, body.category,
        Number(body.sellPrice) || 0, Number(body.wholesalePrice) || 0, Number(body.semiPrice) || 0,
        Number(body.costPrice) || 0, Number(body.quantity) || 0, Number(body.minQuantity) || 0,
        rows[i][10], body.status || rows[i][11]
      ]]);
      return jsonOk({ id: id, updated: true });
    }
  }
  for (var j = 1; j < rows.length; j++) {
    if (rows[j][2] && rows[j][2].toString() === barcode) return jsonError('الباركود موجود مسبقاً');
  }

  addRow(sh, [
    id, body.name, barcode, body.category,
    Number(body.sellPrice) || 0, Number(body.wholesalePrice) || 0, Number(body.semiPrice) || 0,
    Number(body.costPrice) || 0, Number(body.quantity) || 0, Number(body.minQuantity) || 0,
    new Date().toISOString(), 'نشط'
  ]);
  return jsonOk({ id: id });
}

function handleUpdateProduct(body, userCheck) {
  if (!hasPermission(userCheck, 'products')) return jsonError('لا تملك صلاحية تعديل المنتجات');
  var sh = getSheet(SHEET_PRODUCTS);
  var rows = readSheet(sh);
  var id = body.id.toString();
  var found = null;
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === id) { found = i + 1; break; }
  }
  if (!found) return jsonError('المنتج غير موجود');
  sh.getRange(found, 2, 1, 11).setValues([[
    body.name, body.barcode || rows[found - 1][2], body.category,
    Number(body.sellPrice) || 0, Number(body.wholesalePrice) || 0, Number(body.semiPrice) || 0,
    Number(body.costPrice) || 0, Number(body.quantity) || 0, Number(body.minQuantity) || 0,
    rows[found - 1][10], body.status || rows[found - 1][11]
  ]]);
  return jsonOk({ ok: true });
}

function handleDeleteProduct(body, userCheck) {
  if (!hasPermission(userCheck, 'products')) return jsonError('لا تملك صلاحية حذف المنتجات');
  var sh = getSheet(SHEET_PRODUCTS);
  var rows = readSheet(sh);
  var id = body.id.toString();
  for (var i = rows.length - 1; i >= 1; i--) {
    if (rows[i][0] && rows[i][0].toString() === id) { sh.deleteRow(i + 1); }
  }
  return jsonOk({ ok: true });
}

/**
 * ====== الأقسام ======
 */
function handleGetCategories() {
  var sh = getSheet(SHEET_CATEGORIES);
  var rows = readSheet(sh);
  var cats = [];
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0]) cats.push(rows[i][0].toString());
  }
  return jsonOk(cats);
}

function handleAddCategory(body) {
  if (!body.name) return jsonError('اسم القسم مطلوب');
  var sh = getSheet(SHEET_CATEGORIES);
  var rows = readSheet(sh);
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === body.name) return jsonError('القسم موجود مسبقاً');
  }
  addRow(sh, [body.name]);
  return jsonOk({ ok: true });
}

/**
 * ====== المبيعات ======
 */
function handleCreateSale(body, userCheck) {
  if (!hasPermission(userCheck, 'sales')) return jsonError('لا تملك صلاحية إجراء العمليات البيعية');

  var items = body.items || [];
  if (items.length === 0) return jsonError('السلة فارغة');

  var dateObj = new Date();
  var invoiceNo = (body.invoiceNo && String(body.invoiceNo).trim()) ? String(body.invoiceNo).trim() : ('F' + Date.now().toString().slice(-8));

  var productsSheet = getSheet(SHEET_PRODUCTS);
  var productsRows = readSheet(productsSheet);

  var subtotal = 0;

  for (var it = 0; it < items.length; it++) {
    var item = items[it];
    var qty = Number(item.qty) || 0;
    var price = Number(item.price) || 0;
    // التحقق من المخزون
    var pIndex = -1;
    for (var pi = 1; pi < productsRows.length; pi++) {
      if (productsRows[pi][0] && productsRows[pi][0].toString() === (item.id || '').toString()) { pIndex = pi; break; }
    }
    if (pIndex === -1) return jsonError('المنتج غير موجود: ' + item.id);
    var stock = Number(productsRows[pIndex][8]) || 0;
    if (qty > stock) return jsonError('الكمية غير متوفرة للمنتج: ' + productsRows[pIndex][1] + ' (المتاح: ' + stock + ')');
    subtotal += qty * price;
  }

  var taxRate = Number(getSetting('نسبة الضريبة', '0')) || 0;
  var isTaxOn = getSetting('كل يوم ضريبة', 'FALSE') === 'TRUE' || getSetting('كل يوم ضريبة', 'FALSE') === 'true';
  var tax = isTaxOn ? (subtotal * taxRate / 100) : 0;
  var discount = Number(body.discount) || 0;
  var total = subtotal - discount + tax;
  // إذا حُدد المدفوع صراحةً (حتى 0) نستخدمه، وإلا نعتبره إجمالي المبلغ
  var paid = (body.paid !== undefined && body.paid !== '') ? (Number(body.paid) || 0) : total;
  if (paid < 0) paid = 0;
  var balance = total - paid;
  if (balance < 0) balance = 0;
  var paymentMethod = body.paymentMethod || 'كاش';

  // حفظ الفاتورة
  var salesSheet = getSheet(SHEET_SALES);
  var existingSales = readSheet(salesSheet);
  for (var esi = 1; esi < existingSales.length; esi++) {
    if (existingSales[esi][0] && String(existingSales[esi][0]) === invoiceNo) {
      // الفاتورة موجودة بالفعل: إذا طابقت البيانات نفسها فهي إعادة محاولة بعد نجاح
      // سابق (استجابة ضاعت) — نعتبرها مرفوعة ولا نكررها كي لا تتضاعف الكميات.
      var sameCustomer = String(existingSales[esi][4] || '') === String(body.customer || '');
      var sameTotal = Number(existingSales[esi][8]) === total;
      if (sameCustomer && sameTotal) return jsonOk({ ok: true, already: true, invoiceNo: invoiceNo });
      return jsonError('رقم الفاتورة مكرر: ' + invoiceNo);
    }
  }
  addRow(salesSheet, [
    invoiceNo, formatDate(dateObj), formatTime(dateObj),
    body.cashier || userCheck.name || '', body.customer || '',
    subtotal, discount, tax, total, paid, balance, paymentMethod, 'مكتملة',
    body.customerPhone || '', 0, 0
  ]);

  // حفظ بنود الفاتورة وتحديث المخزون
  var itemsSheet = getSheet(SHEET_SALE_ITEMS);
  for (var i = 0; i < items.length; i++) {
    var itm = items[i];
    var pid = (itm.id || '').toString();
    var pRow = -1;
    for (var k = 1; k < productsRows.length; k++) {
      if (productsRows[k][0] && productsRows[k][0].toString() === pid) { pRow = k; break; }
    }
    var name = pRow > -1 ? productsRows[pRow][1] : '';
    var cost = pRow > -1 ? (Number(productsRows[pRow][7]) || 0) : 0;
    var wprice = pRow > -1 ? (Number(productsRows[pRow][5]) || 0) : 0;
    var salePrice = Number(itm.price) || wprice;
    var baseP = (itm.basePrice !== undefined && itm.basePrice !== null) ? (Number(itm.basePrice) || 0) : 0;
    if (!baseP) baseP = salePrice;
    addRow(itemsSheet, [invoiceNo, pid, name, Number(itm.qty) || 0, salePrice, (Number(itm.qty) || 0) * salePrice, cost, baseP]);
    // خصم المخزون
    if (pRow > -1) {
      var newQty = (Number(productsRows[pRow][8]) || 0) - (Number(itm.qty) || 0);
      productsSheet.getRange(pRow + 1, 9).setValue(newQty);
      if (newQty <= (Number(productsRows[pRow][9]) || 0)) {
        // تنبيه نقص المخزون (يُرسل عبر نتيجة)
      }
    }
  }

  // تحديث رصيد العميل المدين + تسجيل تفاصيل الآجل
  var isCredit = (String(paymentMethod) === 'آجل / دين') || balance > 0;
  if (body.customer && isCredit) {
    var custSheet = getSheet(SHEET_CUSTOMERS);
    var custRows = readSheet(custSheet);
    var custFound = false;
    for (var c = 1; c < custRows.length; c++) {
      if (custRows[c][1] && custRows[c][1].toString() === body.customer.toString()) {
        var curDebt = Number(custRows[c][4]) || 0;
        custSheet.getRange(c + 1, 5).setValue(curDebt + balance);
        custFound = true;
        break;
      }
    }
    // تسجيل عميل جديد إذا لم يوجد (ببيانات الآجل)
    if (!custFound) {
      var newCustId = 'C' + Date.now().toString().slice(-6);
      addRow(custSheet, [newCustId, body.customer, body.customerPhone || '', body.customerAddress || '', balance, 0, new Date().toISOString()]);
    }
    // حفظ تفاصيل الآجل في ورقة مستقلة
    var cdSheet = getSheet(SHEET_CREDIT_DETAILS);
    addRow(cdSheet, [
      invoiceNo,
      body.customer || '',
      body.customerPhone || '',
      body.customerAddress || '',
      body.customerIdNumber || '',
      body.guarantorName || '',
      body.guarantorAddress || '',
      body.guarantorPhone || '',
      balance,
      formatDate(dateObj)
    ]);
  }

  var lowStockAlerts = [];
  var productsRows2 = readSheet(productsSheet);
  for (var q = 1; q < productsRows2.length; q++) {
    if ((Number(productsRows2[q][8]) || 0) <= (Number(productsRows2[q][9]) || 0)) {
      lowStockAlerts.push(productsRows2[q][1] + ' (متبقي ' + productsRows2[q][8] + ')');
    }
  }

  return jsonOk({ invoiceNo: invoiceNo, total: total, paid: paid, balance: balance, tax: tax, discount: discount, subtotal: subtotal, lowStock: lowStockAlerts });
}

function handleDeleteSale(body, userCheck) {
  if (!hasPermission(userCheck, 'salesDelete')) return jsonError('لا تملك صلاحية إدارة المبيعات');
  var invoiceNo = (body.invoiceNo || '').toString();

  var salesSheet = getSheet(SHEET_SALES);
  var rows = readSheet(salesSheet);
  var saleRow = -1;
  var balance = 0, customer = '', paymentMethod = '';
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === invoiceNo) {
      saleRow = i;
      balance = Number(rows[i][10]) || 0;
      customer = String(rows[i][4] || '');
      paymentMethod = String(rows[i][11] || '');
      break;
    }
  }
  if (saleRow === -1) return jsonOk({ ok: true, already: true }); // الفاتورة محذوفة سلفاً = نجاح (حذف لا يحتمل التكرار)

  // حذف بنود الفاتورة وإرجاع الكميات للمخزون
  var itemsSheet = getSheet(SHEET_SALE_ITEMS);
  var itemsRows = readSheet(itemsSheet);
  var productsSheet = getSheet(SHEET_PRODUCTS);
  var productsRows = readSheet(productsSheet);
  for (var j = itemsRows.length - 1; j >= 1; j--) {
    if (itemsRows[j][0] && itemsRows[j][0].toString() === invoiceNo) {
      var pid = String(itemsRows[j][1] || '');
      var qty = Number(itemsRows[j][3]) || 0;
      for (var pk = 1; pk < productsRows.length; pk++) {
        if (productsRows[pk][0] && productsRows[pk][0].toString() === pid) {
          var newQty = (Number(productsRows[pk][8]) || 0) + qty;
          productsSheet.getRange(pk + 1, 9).setValue(newQty);
          productsRows = readSheet(productsSheet);
          break;
        }
      }
      itemsSheet.deleteRow(j + 1);
    }
  }

  // إذا كانت الفاتورة آجلة: إلغاء الزيادة على رصيد العميل + حذف تفاصيل الآجل للفاتورة
  if (customer && (balance > 0 || String(paymentMethod) === 'آجل / دين')) {
    var custSheet = getSheet(SHEET_CUSTOMERS);
    var custRows = readSheet(custSheet);
    for (var c = 1; c < custRows.length; c++) {
      if (custRows[c][1] && custRows[c][1].toString() === customer) {
        var curDebt = Number(custRows[c][4]) || 0;
        custSheet.getRange(c + 1, 5).setValue(Math.max(0, curDebt - balance));
        break;
      }
    }
    var cdSheet = getSheet(SHEET_CREDIT_DETAILS);
    var cdRows = readSheet(cdSheet);
    for (var d = cdRows.length - 1; d >= 1; d--) {
      if (cdRows[d][0] && cdRows[d][0].toString() === invoiceNo) cdSheet.deleteRow(d + 1);
    }
  }

  // حذف الفاتورة نفسها
  salesSheet.deleteRow(saleRow + 1);
  return jsonOk({ ok: true });
}

// حذف صنف واحد من فاتورة: تُعاد الكمية غير المُرجعَة إلى المخزون وتُحتسب الإجماليات من جديد
function handleDeleteSaleItem(body, userCheck) {
  if (!hasPermission(userCheck, 'reports')) return jsonError('لا تملك صلاحية إدارة المبيعات');
  var invoiceNo = (body.invoiceNo || '').toString();
  var productId = (body.productId || '').toString();
  if (!invoiceNo || !productId) return jsonError('فاتورة وصنف مطلوبان');

  var salesSheet = getSheet(SHEET_SALES);
  var rows = readSheet(salesSheet);
  var saleRow = -1;
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === invoiceNo) { saleRow = i; break; }
  }
  if (saleRow === -1) return jsonError('الفاتورة غير موجودة');
  var sr = rows[saleRow];
  if (String(sr[12]) === 'مرجوع') return jsonError('لا يمكن تعديل فاتورة مرجوعة بالكامل');

  var itemsSheet = getSheet(SHEET_SALE_ITEMS);
  var itemsRows = readSheet(itemsSheet);
  var itIdx = -1;
  for (var ii = 1; ii < itemsRows.length; ii++) {
    if (itemsRows[ii][0] && itemsRows[ii][0].toString() === invoiceNo && itemsRows[ii][1] && itemsRows[ii][1].toString() === productId) { itIdx = ii; break; }
  }
  if (itIdx === -1) return jsonError('الصنف غير موجود في هذه الفاتورة');
  var itm = itemsRows[itIdx];
  var itmQty = Number(itm[3]) || 0;
  var itmTotal = Number(itm[5]) || 0;

  var retQty = 0;
  var retSheet = getSheet(SHEET_RETURNS);
  var retRows = readSheet(retSheet);
  for (var rr = 1; rr < retRows.length; rr++) {
    if (retRows[rr][1] && retRows[rr][1].toString() === invoiceNo && retRows[rr][3] && retRows[rr][3].toString() === productId && String(retRows[rr][8] || '') === 'استرجاع') retQty += Number(retRows[rr][4]) || 0;
  }
  var restoreQty = Math.max(0, itmQty - retQty);
  var prodSheet = getSheet(SHEET_PRODUCTS);
  var prodRows = readSheet(prodSheet);
  for (var pk = 1; pk < prodRows.length; pk++) {
    if (prodRows[pk][0] && prodRows[pk][0].toString() === productId) {
      prodSheet.getRange(pk + 1, 9).setValue((Number(prodRows[pk][8]) || 0) + restoreQty);
      break;
    }
  }
  itemsSheet.deleteRow(itIdx + 1);

  var oldSubtotal = Number(sr[5]) || 0;
  var newSubtotal = Math.max(0, oldSubtotal - itmTotal);
  var oldDiscount = Number(sr[6]) || 0;
  var oldTax = Number(sr[7]) || 0;
  var newDiscount = oldSubtotal > 0 ? oldDiscount * newSubtotal / oldSubtotal : 0;
  var newTax = oldSubtotal > 0 ? oldTax * newSubtotal / oldSubtotal : 0;
  var newTotal = newSubtotal - newDiscount + newTax;
  var paid = Number(sr[9]) || 0;
  var oldBalance = Number(sr[10]) || 0;
  var newBalance = Math.max(0, newTotal - paid);
  var customer = String(sr[4] || '');
  function money2(v) { return Math.round(Number(v || 0) * 100) / 100; }

  var remainItems = false;
  var itemsRows2 = readSheet(itemsSheet);
  for (var rr2 = 1; rr2 < itemsRows2.length; rr2++) {
    if (itemsRows2[rr2][0] && itemsRows2[rr2][0].toString() === invoiceNo) { remainItems = true; break; }
  }
  if (!remainItems) {
    if (customer && (oldBalance > 0 || String(sr[11]) === 'آجل / دين')) {
      var custSheet = getSheet(SHEET_CUSTOMERS);
      var custRows = readSheet(custSheet);
      for (var c = 1; c < custRows.length; c++) {
        if (custRows[c][1] && custRows[c][1].toString() === customer) {
          custSheet.getRange(c + 1, 5).setValue(Math.max(0, (Number(custRows[c][4]) || 0) - oldBalance));
          break;
        }
      }
      var cdSheet = getSheet(SHEET_CREDIT_DETAILS);
      var cdRows = readSheet(cdSheet);
      for (var d = cdRows.length - 1; d >= 1; d--) {
        if (cdRows[d][0] && cdRows[d][0].toString() === invoiceNo) cdSheet.deleteRow(d + 1);
      }
    }
    salesSheet.deleteRow(saleRow + 1);
    return jsonOk({ ok: true, deletedInvoice: true });
  }

  salesSheet.getRange(saleRow + 1, 6).setValue(money2(newSubtotal));
  salesSheet.getRange(saleRow + 1, 7).setValue(money2(newDiscount));
  salesSheet.getRange(saleRow + 1, 8).setValue(money2(newTax));
  salesSheet.getRange(saleRow + 1, 9).setValue(money2(newTotal));
  salesSheet.getRange(saleRow + 1, 11).setValue(money2(newBalance));

  if (customer && (oldBalance > 0 || String(sr[11]) === 'آجل / دين')) {
    var dec = Math.min(oldBalance, Math.max(0, oldBalance - newBalance));
    var custSheet2 = getSheet(SHEET_CUSTOMERS);
    var custRows2 = readSheet(custSheet2);
    for (var c2 = 1; c2 < custRows2.length; c2++) {
      if (custRows2[c2][1] && custRows2[c2][1].toString() === customer) {
        custSheet2.getRange(c2 + 1, 5).setValue(Math.max(0, (Number(custRows2[c2][4]) || 0) - dec));
        break;
      }
    }
    if (newBalance <= 0) {
      var cdSheet2 = getSheet(SHEET_CREDIT_DETAILS);
      var cdRows2 = readSheet(cdSheet2);
      for (var d2 = cdRows2.length - 1; d2 >= 1; d2--) {
        if (cdRows2[d2][0] && cdRows2[d2][0].toString() === invoiceNo) cdSheet2.deleteRow(d2 + 1);
      }
    } else {
      var cdSheet3 = getSheet(SHEET_CREDIT_DETAILS);
      var cdRows3 = readSheet(cdSheet3);
      for (var d3 = 1; d3 < cdRows3.length; d3++) {
        if (cdRows3[d3][0] && cdRows3[d3][0].toString() === invoiceNo) {
          cdSheet3.getRange(d3 + 1, 9).setValue(money2(newBalance));
          break;
        }
      }
    }
  }
  return jsonOk({ ok: true });
}

function handleGetSales(body, userCheck) {
  if (!hasPermission(userCheck, 'reports') && !hasPermission(userCheck, 'sales')) return jsonError('لا تملك صلاحية عرض المبيعات');
  var sh = getSheet(SHEET_SALES);
  var rows = readSheet(sh);
  var headers = ['invoiceNo', 'date', 'time', 'cashier', 'customer', 'subtotal', 'discount', 'tax', 'total', 'paid', 'balance', 'paymentMethod', 'status', 'customerPhone', 'exchangeCredit', 'refund'];
  var sales = rowsToObjects(rows, headers);
  sales.forEach(function (s) {
    s.subtotal = Number(s.subtotal); s.discount = Number(s.discount); s.tax = Number(s.tax);
    s.total = Number(s.total); s.paid = Number(s.paid); s.balance = Number(s.balance);
  });
  // فلترة حسب التاريخ إذا طُلب
  if (body.from || body.to) {
    sales = sales.filter(function (s) {
      var ds = toDate(s.date);
      if (!ds) return false;
      if (body.from && ds < toDate(body.from)) return false;
      if (body.to && ds > toDate(body.to)) return false;
      return true;
    });
  }
  return jsonOk(sales);
}

function handleGetSaleItems(body) {
  var sh = getSheet(SHEET_SALE_ITEMS);
  var rows = readSheet(sh);
  var headers = ['invoiceNo', 'productId', 'name', 'qty', 'price', 'total', 'cost', 'basePrice'];
  var items = rowsToObjects(rows, headers);
  items.forEach(function (s) { s.qty = Number(s.qty); s.price = Number(s.price); s.total = Number(s.total); s.cost = Number(s.cost); s.basePrice = (s.basePrice && s.basePrice !== '') ? Number(s.basePrice) : s.price; });
  if (body.invoiceNo) {
    items = items.filter(function (it) { return it.invoiceNo === body.invoiceNo; });
  }
  return jsonOk(items);
}

/**
 * ====== العملاء ======
 */
function handleGetCustomers() {
  var sh = getSheet(SHEET_CUSTOMERS);
  var rows = readSheet(sh);
  var headers = ['id', 'name', 'phone', 'address', 'debt', 'creditLimit', 'addedDate'];
  var customers = rowsToObjects(rows, headers);
  customers.forEach(function (c) { c.debt = Number(c.debt) || 0; c.creditLimit = Number(c.creditLimit) || 0; });

  // إثراء بيانات الضامن من آخر سجل في تفاصيل الآجل (يظهر في جدول العملاء + تفاصيل العميل)
  var cdSheet = getSheet(SHEET_CREDIT_DETAILS);
  var cdRows = readSheet(cdSheet);
  var cdHeaders = ['invoiceNo', 'customer', 'phone', 'address', 'idNumber', 'guarantorName', 'guarantorAddress', 'guarantorPhone', 'amount', 'date'];
  var latestCd = {};
  for (var i = 1; i < cdRows.length; i++) {
    var cname = cdRows[i][1] ? cdRows[i][1].toString() : '';
    if (cname) latestCd[cname] = i; // آخر سجل لكل عميل
  }
  customers.forEach(function (c) {
    var li = latestCd[c.name];
    if (li && cdRows[li]) {
      c.guarantorName = cdRows[li][5] || '';
      c.guarantorPhone = cdRows[li][7] || '';
      c.guarantorAddress = cdRows[li][6] || '';
      c.idNumber = cdRows[li][4] || '';
    }
  });

  return jsonOk(customers);
}

function handleAddCustomer(body) {
  var sh = getSheet(SHEET_CUSTOMERS);
  var id = body.id || ('C' + Date.now().toString().slice(-6));
  addRow(sh, [id, body.name, body.phone || '', body.address || '', Number(body.debt) || 0, Number(body.creditLimit) || 0, new Date().toISOString()]);
  return jsonOk({ id: id });
}

function handleUpdateCustomer(body) {
  var sh = getSheet(SHEET_CUSTOMERS);
  var rows = readSheet(sh);
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === (body.id || '').toString()) {
      sh.getRange(i + 1, 2, 1, 5).setValues([[
        body.name, body.phone || '', body.address || '',
        body.debt !== undefined && body.debt !== '' ? Number(body.debt) : (Number(rows[i][4]) || 0),
        body.creditLimit !== undefined && body.creditLimit !== '' ? Number(body.creditLimit) : (Number(rows[i][5]) || 0)
      ]]);
      return jsonOk({ ok: true });
    }
  }
  // العميل غير موجود: نضيفه بدلاً من الخطأ لتفادي تعليق صف في قائمة الانتظار
  var id = body.id || ('C' + Date.now().toString().slice(-6));
  addRow(sh, [id, body.name || '', body.phone || '', body.address || '', Number(body.debt) || 0, Number(body.creditLimit) || 0, new Date().toISOString()]);
  return jsonOk({ ok: true, created: true });
}

function handleDeleteCustomer(body) {
  var sh = getSheet(SHEET_CUSTOMERS);
  var rows = readSheet(sh);
  for (var i = rows.length - 1; i >= 1; i--) {
    if (rows[i][0] && rows[i][0].toString() === (body.id || '').toString()) { sh.deleteRow(i + 1); }
  }
  return jsonOk({ ok: true });
}

function handleAddPayment(body) {
  var sh = getSheet(SHEET_CUSTOMERS);
  var rows = readSheet(sh);
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === (body.customerId || '').toString()) {
      var curDebt = Number(rows[i][4]) || 0;
      // الرصيد المدين يقبل الرصيد السالب = العميل له رصيد لدينا (سدد أكثر من مستحقه)
      var newDebt = curDebt - (Number(body.amount) || 0);
      sh.getRange(i + 1, 5).setValue(newDebt);
      // توزيع التسديد تلقائياً على فواتير العميل المفتوحة (الأقدم أولاً) ليظهر السداد في سجل الآجل
      allocatePaymentToInvoices(rows[i][1], Number(body.amount) || 0);
      // تسجيل عملية التسديد في سجل تسديد الآجل
      try {
        var paySheet = getSheet(SHEET_PAYMENTS);
        addRow(paySheet, [rows[i][0], rows[i][1], Number(body.amount) || 0, formatDate(new Date()), body.cashier || '']);
      } catch (e) { Logger.log('تعذر تسجيل الدفعة: ' + e.toString()); }
      return jsonOk({ ok: true, newDebt: newDebt });
    }
  }
  return jsonError('العميل غير موجود');
}

// توزيع مبلغ التسديد على فواتير العميل المفتوحة (الأقدم أولاً) وتقليل أرصدتها فعلياً
function allocatePaymentToInvoices(customerName, amount) {
  var remaining = Number(amount) || 0;
  if (remaining <= 0) return 0;
  var salesSheet = getSheet(SHEET_SALES);
  var rows = readSheet(salesSheet);
  for (var i = 1; i < rows.length && remaining > 0; i++) {
    var r = rows[i];
    if (!r) continue;
    if (String(r[4] || '') !== String(customerName)) continue;
    if (String(r[12] || '') === 'مرجوع') continue; // فاتورة مُرجعة بالكامل
    var bal = Number(r[10]) || 0;
    if (bal <= 0) continue;
    var part = Math.min(bal, remaining);
    var paid = (Number(r[9]) || 0) + part;
    bal -= part;
    remaining -= part;
    r[9] = paid;
    r[10] = bal;
    salesSheet.getRange(i + 1, 10).setValue(paid);
    salesSheet.getRange(i + 1, 11).setValue(bal);
  }
  return remaining;
}

function handleGetPayments(body) {
  var sh = getSheet(SHEET_PAYMENTS);
  var rows = readSheet(sh);
  var headers = ['customerId', 'name', 'amount', 'date', 'cashier'];
  var payments = rowsToObjects(rows, headers);
  // تصفية حسب العميل إن طُلب
  if (body && body.customerId) {
    payments = payments.filter(function (p) {
      return p.customerId !== undefined && p.customerId !== null &&
        p.customerId.toString() === (body.customerId || '').toString();
    });
  }
  return jsonOk(payments);
}

/**
 * ====== الموردين ======
 */
// يقرأ سجل تسديد الموردين ويعيد لكل مورد: إجمالي الأديان اليدوية + إجمالي التسديدات
function supplierLedgerTotals() {
  var out = {};
  var sh;
  try { sh = getSheet(SHEET_SUPPLIER_PAYMENTS); } catch (e) { return out; }
  if (!sh) return out;
  var rows = readSheet(sh);
  // الأعمدة: 0 المعرّف، 1 المورد، 2 التاريخ، 3 الوقت، 4 النوع، 5 المبلغ، 6 ملاحظات، 7 الكاشير، 8 رقم الشراء
  for (var i = 1; i < rows.length; i++) {
    var r = rows[i];
    if (!r) continue;
    // الحركات المرتبطة بفاتورة شراء تُحسب تلقائياً عبر purchases (إجمالي/مدفوع/متبقي)
    if (String(r[8] || '') !== '') continue;
    var sname = String(r[1] || '');
    if (!sname) continue;
    if (!out[sname]) out[sname] = { debt: 0, paid: 0, count: 0 };
    var amt = Number(r[5]) || 0;
    var typ = String(r[4] || '');
    out[sname].count++;
    if (typ === 'دين') out[sname].debt += amt; else out[sname].paid += amt;
  }
  return out;
}

function handleGetSuppliers() {
  var sh = getSheet(SHEET_SUPPLIERS);
  var rows = readSheet(sh);
  var headers = ['id', 'name', 'phone', 'address', 'notes', 'credit'];
  var suppliers = rowsToObjects(rows, headers);

  // حساب الدين: مجموع المتبقي على فواتير الشراء لكل مورد
  var purSheet = getSheet(SHEET_PURCHASES);
  var purRows = readSheet(purSheet);
  var suppMap = {}; // name -> {total,purchased,paid,remaining,lastDate}
  for (var i = 1; i < purRows.length; i++) {
    if (!purRows[i]) continue;
    var sname = String(purRows[i][2] || '');
    if (!sname) continue;
    if (!suppMap[sname]) suppMap[sname] = { purchased: 0, paid: 0, remaining: 0, lastDate: '' };
    var t = Number(purRows[i][3]) || 0, pa = Number(purRows[i][4]) || 0, re = Number(purRows[i][5]) || 0;
    suppMap[sname].purchased += t;
    suppMap[sname].paid += pa;
    suppMap[sname].remaining += re;
    if (String(purRows[i][1] || '') > suppMap[sname].lastDate) suppMap[sname].lastDate = String(purRows[i][1] || '');
  }
  var ledger = supplierLedgerTotals();
  suppliers.forEach(function (s) {
    var m = suppMap[s.name] || { purchased: 0, paid: 0, remaining: 0, lastDate: '' };
    var ld = ledger[s.name] || { debt: 0, paid: 0 };
    s.debt = m.remaining;          // المتبقي على فواتير الشراء (له عليا)
    s.manualDebt = ld.debt;        // أديان يدوية سجّلها المستخدم (له عليا)
    s.ledgerPayments = ld.paid;    // تسديدات سجلّها المستخدم (خفضت الدين)
    s.ledgerCount = ld.count;
    s.totalPurchased = m.purchased;
    s.totalPaid = m.paid;
    s.lastPurchaseDate = m.lastDate;
    s.credit = Number(s.credit) || 0;                     // رصيد لنا عند المورد (سلفة / مقدم)
    s.netBalance = m.remaining + ld.debt - ld.paid - s.credit; // موجب = له عليا، سالب = لنا عنده
  });
  return jsonOk(suppliers);
}

// سجل تسديد/حركة المورد (دين أو تسديد) حسب المورد
function handleGetSupplierPayments(body) {
  var sh = getSheet(SHEET_SUPPLIER_PAYMENTS);
  var rows = readSheet(sh);
  var out = [];
  var supplier = String(body.supplier || body.supplierName || '');
  for (var i = 1; i < rows.length; i++) {
    var r = rows[i];
    if (!r) continue;
    if (supplier && String(r[1] || '') !== supplier) continue;
    out.push({
      id: String(r[0] || ''), supplier: String(r[1] || ''), date: String(r[2] || ''),
      time: String(r[3] || ''), type: String(r[4] || ''), amount: Number(r[5]) || 0,
      notes: String(r[6] || ''), cashier: String(r[7] || ''), purchaseNo: String(r[8] || '')
    });
  }
  return jsonOk(out);
}

// إضافة دين جديد على المورد أو تسديد دين للمورد (نفس البنية، النوع يحدده الإجراء)
function handleSupplierPayment(body, auth, type) {
  if (!hasPermission(auth, 'suppliers')) return jsonError('لا تملك صلاحية إدارة الموردين');
  var supplier = String(body.supplier || '');
  var amount = Number(body.amount) || 0;
  if (!supplier) return jsonError('اختر المورد');
  if (amount <= 0) return jsonError('أدخل مبلغاً صحيحاً أكبر من صفر');
  var sh = getSheet(SHEET_SUPPLIER_PAYMENTS);
  if (sh.getLastRow() < 1) setHeaders(sh, BACKUP_HEADERS.supplierPayments);
  var now = new Date();
  var date = String(body.date || Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd'));
  var time = String(body.time || Utilities.formatDate(now, Session.getScriptTimeZone(), 'HH:mm:ss'));
  var id = 'SP' + Date.now().toString().slice(-8) + Math.floor(Math.random() * 90 + 10);
  var cashier = String((auth && auth.user ? auth.user : null) || body.cashier || '');
  addRow(sh, [id, supplier, date, time, type, amount, String(body.notes || ''), cashier, String(body.purchaseNo || '')]);
  return jsonOk({ id: id });
}

function handleAddSupplier(body) {
  var sh = getSheet(SHEET_SUPPLIERS);
  var id = body.id || ('S' + Date.now().toString().slice(-6));
  addRow(sh, [id, body.name, body.phone || '', body.address || '', body.notes || '', Number(body.credit) || 0]);
  return jsonOk({ id: id });
}

function handleUpdateSupplier(body) {
  var sh = getSheet(SHEET_SUPPLIERS);
  var rows = readSheet(sh);
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === (body.id || '').toString()) {
      sh.getRange(i + 1, 2, 1, 5).setValues([[body.name, body.phone || '', body.address || '', body.notes || '', Number(body.credit) || 0]]);
      return jsonOk({ ok: true });
    }
  }
  return jsonError('المورد غير موجود');
}

function handleDeleteSupplier(body) {
  var sh = getSheet(SHEET_SUPPLIERS);
  var rows = readSheet(sh);
  for (var i = rows.length - 1; i >= 1; i--) {
    if (rows[i][0] && rows[i][0].toString() === (body.id || '').toString()) { sh.deleteRow(i + 1); }
  }
  return jsonOk({ ok: true });
}

/**
 * ====== المشتريات ======
 */
function handleCreatePurchase(body, userCheck) {
  if (!hasPermission(userCheck, 'purchases')) return jsonError('لا تملك صلاحية إدارة المشتريات');

  var items = body.items || [];
  if (items.length === 0) return jsonError('المشتريات فارغة');

  var purchaseNo = 'PR' + Date.now().toString().slice(-8);
  var dateObj = new Date();
  var total = 0;
  items.forEach(function (it) { total += (Number(it.qty) || 0) * (Number(it.price) || 0); });

  var paid = Number(body.paid) || 0;
  var remaining = total - paid;

  var purSheet = getSheet(SHEET_PURCHASES);
  addRow(purSheet, [purchaseNo, formatDate(dateObj), body.supplier || '', total, paid, remaining, body.cashier || (userCheck.name || ''), 'مكتملة']);

  // تسجيل الحساب على المورد في سجل تسديد الموردين (دين/دفع)، مرتبطاً برقم الفاتورة
  if (body.supplier) {
    var supSheet = getSheet(SHEET_SUPPLIERS);
    var supRows = readSheet(supSheet);
    var supExists = false;
    for (var si = 1; si < supRows.length; si++) {
      if (supRows[si] && supRows[si][1] && supRows[si][1].toString() === String(body.supplier)) { supExists = true; break; }
    }
    if (!supExists) addRow(supSheet, ['S' + Date.now().toString().slice(-6), body.supplier, '', '', '', 0]);
    var spSheet = getSheet(SHEET_SUPPLIER_PAYMENTS);
    if (spSheet.getLastRow() < 1) setHeaders(spSheet, BACKUP_HEADERS.supplierPayments);
    var now = new Date();
    var dateStr = Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd');
    var timeStr = Utilities.formatDate(now, Session.getScriptTimeZone(), 'HH:mm:ss');
    var cashierName = String(body.cashier || (userCheck ? userCheck.name : '') || '');
    if (remaining > 0) {
      var dId = 'SP' + Date.now().toString().slice(-8) + Math.floor(Math.random() * 90 + 10);
      addRow(spSheet, [dId, body.supplier, dateStr, timeStr, 'دين', remaining, 'فاتورة شراء ' + purchaseNo + ' (متبقي)', cashierName, purchaseNo]);
    }
    if (paid > 0) {
      var pId = 'SP' + (Date.now() + 1).toString().slice(-8) + Math.floor(Math.random() * 90 + 10);
      addRow(spSheet, [pId, body.supplier, dateStr, timeStr, 'تسديد', paid, 'دفعة فاتورة شراء ' + purchaseNo, cashierName, purchaseNo]);
    }
  }

  var purItemsSheet = getSheet(SHEET_PURCHASE_ITEMS);
  var productsSheet = getSheet(SHEET_PRODUCTS);
  var productsRows = readSheet(productsSheet);

  for (var i = 0; i < items.length; i++) {
    var itm = items[i];
    var pid = (itm.productId || '').toString();
    var name = itm.name || '';
    var qty = Number(itm.qty) || 0;
    var price = Number(itm.price) || 0;
    addRow(purItemsSheet, [purchaseNo, pid, name, qty, price, qty * price]);

    // إضافة للمخزون (أو إنشاء منتج جديد)
    var pRow = -1;
    for (var k = 1; k < productsRows.length; k++) {
      if (productsRows[k][0] && productsRows[k][0].toString() === pid) { pRow = k; break; }
    }
    if (pRow > -1) {
      // اعتماداً على عدد القطع الموجودة والسابقة: متوسط التكلفة الموزونة
      var oldQty = Number(productsRows[pRow][8]) || 0;
      var oldCost = Number(productsRows[pRow][7]) || 0;
      var newQty = oldQty + qty;
      var avgCost = (oldQty * oldCost + qty * price) / newQty;
      productsSheet.getRange(pRow + 1, 9).setValue(newQty);
      productsSheet.getRange(pRow + 1, 8).setValue(avgCost);
    } else {
      // منتج جديد من الشراء
      addRow(productsSheet, [pid, name, pid, body.supplier || 'غير محدد', 0, 0, 0, price, qty, 0, new Date().toISOString(), 'نشط']);
      productsRows = readSheet(productsSheet);
    }
  }

  return jsonOk({ purchaseNo: purchaseNo, total: total, paid: paid, remaining: remaining });
}

function handleGetPurchases(body) {
  var sh = getSheet(SHEET_PURCHASES);
  var rows = readSheet(sh);
  var headers = ['purchaseNo', 'date', 'supplier', 'total', 'paid', 'remaining', 'cashier', 'status'];
  var purchases = rowsToObjects(rows, headers);
  purchases.forEach(function (p) { p.total = Number(p.total); p.paid = Number(p.paid); p.remaining = Number(p.remaining); });
  return jsonOk(purchases);
}

function handleGetPurchaseItems(body) {
  var sh = getSheet(SHEET_PURCHASE_ITEMS);
  var rows = readSheet(sh);
  var headers = ['purchaseNo', 'productId', 'name', 'qty', 'price', 'total'];
  var items = rowsToObjects(rows, headers);
  items.forEach(function (it) { it.qty = Number(it.qty); it.price = Number(it.price); it.total = Number(it.total); });
  if (body.purchaseNo) items = items.filter(function (it) { return it.purchaseNo === body.purchaseNo; });
  return jsonOk(items);
}

// تسديد/تعديل المدفوع في فاتورة شراء (عند وجود رصيد متبقي)
function handleSettlePurchase(body, userCheck) {
  if (!hasPermission(userCheck, 'purchases')) return jsonError('لا تملك صلاحية إدارة المشتريات');
  var sh = getSheet(SHEET_PURCHASES);
  var rows = readSheet(sh);
  var purNo = (body.purchaseNo || '').toString();
  var extra = Number(body.amount) || 0;
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === purNo) {
      var curPaid = Number(rows[i][4]) || 0;
      var curRem = Number(rows[i][5]) || 0;
      var newPaid = Number(rows[i][3]) <= (curPaid + extra) ? Number(rows[i][3]) : (curPaid + extra);
      var newRem = Math.max(0, (Number(rows[i][3]) || 0) - newPaid);
      sh.getRange(i + 1, 5).setValue(newPaid);
      sh.getRange(i + 1, 6).setValue(newRem);
      sh.getRange(i + 1, 8).setValue(newRem <= 0 ? 'مسدد' : 'مكتمل');
      if (extra > 0 && String(rows[i][2] || '')) {
        var spSheet = getSheet(SHEET_SUPPLIER_PAYMENTS);
        if (spSheet.getLastRow() < 1) setHeaders(spSheet, BACKUP_HEADERS.supplierPayments);
        var now = new Date();
        var pId = 'SP' + (Date.now() + i).toString().slice(-8) + Math.floor(Math.random() * 90 + 10);
        var dateStr = Utilities.formatDate(now, Session.getScriptTimeZone(), 'yyyy-MM-dd');
        var timeStr = Utilities.formatDate(now, Session.getScriptTimeZone(), 'HH:mm:ss');
        var cashierName = String(body.cashier || (userCheck ? userCheck.name : '') || '');
        addRow(spSheet, [pId, String(rows[i][2] || ''), dateStr, timeStr, 'تسديد', extra, 'دفعة فاتورة شراء ' + purNo, cashierName, purNo]);
      }
      return jsonOk({ ok: true, paid: newPaid, remaining: newRem });
    }
  }
  return jsonError('فاتورة الشراء غير موجودة');
}

// مرتجع شراء: يُرجع أصنافاً من فاتورة شراء (يُنقص المخزون ويُضيف قيمة المرتجع لرصيد المورد)
function handleCreatePurchaseReturn(body, userCheck) {
  if (!hasPermission(userCheck, 'purchaseReturns')) return jsonError('لا تملك صلاحية إدارة المشتريات');
  var purchaseNo = (body.purchaseNo || '').toString();
  var supplier = (body.supplier || '').toString();
  var returned = body.returned || [];
  if (!purchaseNo) return jsonError('رقم فاتورة الشراء مطلوب');
  if (returned.length === 0) return jsonError('اختر أصنافاً للإرجاع أولاً');

  var purSheet = getSheet(SHEET_PURCHASES);
  var purRows = readSheet(purSheet);
  var purFound = false;
  for (var i = 1; i < purRows.length; i++) {
    if (purRows[i][0] && purRows[i][0].toString() === purchaseNo) {
      purFound = true;
      if (!supplier) supplier = (purRows[i][2] || '').toString();
      break;
    }
  }
  if (!purFound) return jsonError('فاتورة الشراء غير موجودة');

  var itemsSheet = getSheet(SHEET_PURCHASE_ITEMS);
  var itemsRows = readSheet(itemsSheet);

  // المرتجعات السابقة لنفس الفاتورة (حتى لا تتجاوز كمية الشراء)
  var retSheet = getSheet(SHEET_PURCHASE_RETURNS);
  var retRows = readSheet(retSheet);
  var prevRet = {};
  for (var r = 1; r < retRows.length; r++) {
    if (retRows[r][1] && retRows[r][1].toString() === purchaseNo) {
      var key = (retRows[r][3] || '').toString();
      prevRet[key] = (prevRet[key] || 0) + (Number(retRows[r][5]) || 0);
    }
  }

  var returnNo = 'RPR' + String(Date.now()).slice(-8);
  var dateStr = formatDate(new Date());
  var cashier = body.cashier || userCheck.name || '';
  var totalRet = 0;

  var productsSheet = getSheet(SHEET_PRODUCTS);
  var productsRows = readSheet(productsSheet);

  for (var k = 0; k < returned.length; k++) {
    var rit = returned[k];
    var rpid = (rit.productId || '').toString();
    var rqty = Math.floor(Number(rit.qty) || 0);
    if (rqty <= 0) continue;
    var bought = 0, price = 0, name = '';
    for (var si = 1; si < itemsRows.length; si++) {
      if (itemsRows[si][0] && itemsRows[si][0].toString() === purchaseNo && itemsRows[si][1] && itemsRows[si][1].toString() === rpid) {
        bought = Number(itemsRows[si][3]) || 0;
        price = Number(itemsRows[si][4]) || 0;
        name = (itemsRows[si][2] || '').toString();
        break;
      }
    }
    if (bought <= 0) return jsonError('المنتج غير موجود بفاتورة الشراء: ' + (name || rpid));
    if ((prevRet[rpid] || 0) + rqty > bought) return jsonError('كمية الإرجاع تتجاوز المشترى في الفاتورة: ' + (name || rpid));
    var pRow = -1;
    for (var pi = 1; pi < productsRows.length; pi++) {
      if (productsRows[pi][0] && productsRows[pi][0].toString() === rpid) { pRow = pi; break; }
    }
    var curQty = pRow > -1 ? (Number(productsRows[pRow][8]) || 0) : 0;
    if (curQty < rqty) return jsonError('المخزون الحالي (' + curQty + ') أقل من كمية الإرجاع: ' + (name || rpid));
    var lineVal = Math.round(rqty * price * 100) / 100;
    totalRet += lineVal;
    if (pRow > -1) {
      productsSheet.getRange(pRow + 1, 9).setValue(curQty - rqty);
      productsRows = readSheet(productsSheet);
    }
    prevRet[rpid] = (prevRet[rpid] || 0) + rqty;
    addRow(retSheet, [returnNo, purchaseNo, dateStr, rpid, name, rqty, price, lineVal, supplier, cashier, 'مكتمل']);
  }

  if (totalRet === 0) return jsonError('أدخل كميات صحيحة للإرجاع');

  // مزامنة رصيد المورد: تُضاف قيمة المرتجع إلى "رصيد لنا عند المورد"
  if (supplier) {
    var supSheet = getSheet(SHEET_SUPPLIERS);
    var supRows = readSheet(supSheet);
    for (var s = 1; s < supRows.length; s++) {
      if (supRows[s][1] && supRows[s][1].toString() === supplier) {
        var curCredit = Number(supRows[s][5]) || 0;
        supSheet.getRange(s + 1, 6).setValue(Math.round((curCredit + totalRet) * 100) / 100);
        break;
      }
    }
  }

  return jsonOk({ returnNo: returnNo, total: totalRet });
}

function handleGetPurchaseReturns(body) {
  var sh = getSheet(SHEET_PURCHASE_RETURNS);
  var rows = readSheet(sh);
  var headers = ['returnNo', 'purchaseNo', 'date', 'productId', 'name', 'qty', 'price', 'total', 'supplier', 'cashier', 'status'];
  var items = rowsToObjects(rows, headers);
  items.forEach(function (it) {
    it.qty = Number(it.qty) || 0;
    it.price = Number(it.price) || 0;
    it.total = Number(it.total) || 0;
  });
  if (body && body.purchaseNo) {
    var target = (body.purchaseNo || '').toString();
    items = items.filter(function (x) { return x.purchaseNo === target; });
  }
  return jsonOk(items);
}

/**
 * ====== التقارير ======
 */
function handleGetReport(body, userCheck) {
  if (!hasPermission(userCheck, 'reports')) return jsonError('لا تملك صلاحية عرض التقارير');

  var period = body.period || 'today';
  var from = body.from;
  var to = body.to;

  var now = new Date();
  if (!from) {
    if (period === 'today') { from = startOfDay(now); to = now; }
    else if (period === 'yesterday') { var y = new Date(now); y.setDate(y.getDate() - 1); from = startOfDay(y); to = endOfDay(y); }
    else if (period === 'week') { var w = new Date(now); w.setDate(w.getDate() - 7); from = startOfDay(w); to = now; }
    else if (period === 'month') { var m = new Date(now); m.setMonth(m.getMonth() - 1); from = startOfDay(m); to = now; }
    else if (period === 'year') { var yr = new Date(now); yr.setFullYear(yr.getFullYear() - 1); from = startOfDay(yr); to = now; }
    else if (period === 'all') { from = new Date(0); to = now; }
  } else { from = new Date(from); to = new Date(to); }

  var salesSheet = getSheet(SHEET_SALES);
  var salesRows = readSheet(salesSheet);
  var itemsSheet = getSheet(SHEET_SALE_ITEMS);
  var itemsRows = readSheet(itemsSheet);

  var filteredSales = [];
  for (var i = 1; i < salesRows.length; i++) {
    var d = toDate(salesRows[i][1]);
    if (d && d >= from && d <= to) filteredSales.push(salesRows[i]);
  }

  // بناء خريطة حالة الفاتورة وقيم المرتجع
  var statusByInvoice = {};
  for (var si = 0; si < filteredSales.length; si++) {
    statusByInvoice[filteredSales[si][0]] = String(filteredSales[si][12] || 'مكتملة');
  }
  var returnsSheet = getSheet(SHEET_RETURNS);
  var returnsRows = readSheet(returnsSheet);
  var returnedQtyMap = {}, returnedTotalMap = {}, returnedValMap = {};
  // أعمدة المرتجع: [0]=رقم [1]=فاتورة [2]=تاريخ [3]=منتج [4]=كمية [5]=سعر [6]=قيمة صافية [7]=اسم [8]=نوع
  // يُخصم من الفاتورة القديمة نوع 'استرجاع' فقط؛ 'استبدال' قيمته في فاتورته الجديدة ولا تُخصم مزدوجاً.
  for (var ri = 1; ri < returnsRows.length; ri++) {
    if (!returnsRows[ri]) continue;
    if (String(returnsRows[ri][8] || '') !== 'استرجاع') continue;
    var rInv = String(returnsRows[ri][1] || '');
    var rProd = String(returnsRows[ri][3] || '');
    var rQty = Number(returnsRows[ri][4]) || 0;
    var rVal = Number(returnsRows[ri][6]) || 0;
    if (rQty <= 0) continue;
    if (!returnedQtyMap[rInv]) returnedQtyMap[rInv] = {};
    if (!returnedValMap[rInv]) returnedValMap[rInv] = {};
    returnedQtyMap[rInv][rProd] = (returnedQtyMap[rInv][rProd] || 0) + rQty;
    returnedValMap[rInv][rProd] = (returnedValMap[rInv][rProd] || 0) + rVal;
    returnedTotalMap[rInv] = (returnedTotalMap[rInv] || 0) + rVal;
  }

  var totalSales = 0, totalProfit = 0, totalDiscount = 0, totalTax = 0, totalCostOfSold = 0, count = 0;
  var invoiceNumbers = [];

  for (var s = 0; s < filteredSales.length; s++) {
    var row = filteredSales[s];
    var invNo = row[0];
    var status = statusByInvoice[invNo];
    if (status === 'مرجوع') continue;
    count++;
    var invTotal = Number(row[8]) || 0;
    if (status === 'استرجاع جزئي') invTotal -= (returnedTotalMap[invNo] || 0);
    totalSales += invTotal;
    totalDiscount += Number(row[6]) || 0;
    totalTax += Number(row[7]) || 0;
    invoiceNumbers.push(invNo);
  }

  for (var q = 1; q < itemsRows.length; q++) {
    var qInv = itemsRows[q][0];
    if (invoiceNumbers.indexOf(qInv) < 0) continue;
    var st = statusByInvoice[qInv] || 'مكتملة';
    var revenue = (Number(itemsRows[q][5]) || 0);
    var qtyItem = (Number(itemsRows[q][3]) || 0);
    var costPerUnit = (Number(itemsRows[q][6]) || 0);
    var cost = qtyItem * costPerUnit;
    if (st === 'استرجاع جزئي') {
      var retQ = (returnedQtyMap[qInv] && returnedQtyMap[qInv][itemsRows[q][1]]) || 0;
      if (retQ > 0) { revenue -= (returnedValMap[qInv] && returnedValMap[qInv][itemsRows[q][1]]) || 0; cost -= retQ * costPerUnit; }
    }
    totalCostOfSold += cost;
    totalProfit += revenue - cost;
  }

  // أفضل المنتجات
  var productSales = {};
  for (var t = 1; t < itemsRows.length; t++) {
    var tInv = itemsRows[t][0];
    if (invoiceNumbers.indexOf(tInv) < 0) continue;
    var pn = itemsRows[t][2];
    var qty = Number(itemsRows[t][3]) || 0;
    var rev = Number(itemsRows[t][5]) || 0;
    var st2 = statusByInvoice[tInv] || 'مكتملة';
    if (st2 === 'استرجاع جزئي') {
      var rq2 = (returnedQtyMap[tInv] && returnedQtyMap[tInv][itemsRows[t][1]]) || 0;
      if (rq2 > 0) { qty -= rq2; rev -= (returnedValMap[tInv] && returnedValMap[tInv][itemsRows[t][1]]) || 0; }
    }
    if (qty > 0) {
      if (!productSales[pn]) productSales[pn] = { qty: 0, revenue: 0 };
      productSales[pn].qty += qty;
      productSales[pn].revenue += rev;
    }
  }
  var topProducts = Object.keys(productSales).map(function (k) {
    return { name: k, qty: productSales[k].qty, revenue: productSales[k].revenue };
  }).sort(function (a, b) { return b.revenue - a.revenue; }).slice(0, 10);

  // المبيعات حسب اليوم في النطاق
  var dailySales = {};
  for (var u = 0; u < filteredSales.length; u++) {
    var dd = filteredSales[u][1];
    var key = dateKey(dd) || dd;
    var uInv = filteredSales[u][0];
    var uSt = statusByInvoice[uInv];
    if (uSt === 'مرجوع') continue;
    var uAmount = Number(filteredSales[u][8]) || 0;
    if (uSt === 'استرجاع جزئي') uAmount -= (returnedTotalMap[uInv] || 0);
    if (!dailySales[key]) dailySales[key] = 0;
    dailySales[key] += uAmount;
  }
  var dailyArray = Object.keys(dailySales).map(function (k) { return { date: k, total: dailySales[k] }; }).sort(function (a, b) { return a.date < b.date ? -1 : 1; });

  // إجمالي قيمة منتجات المخزون على أساس سعر التكلفة (لحظة التقرير)
  var prodSheet = getSheet(SHEET_PRODUCTS);
  var prodRows = readSheet(prodSheet);
  var totalInventoryCost = 0;
  for (var pr = 1; pr < prodRows.length; pr++) {
    totalInventoryCost += (Number(prodRows[pr][7]) || 0) * (Number(prodRows[pr][8]) || 0);
  }

  // المصاريف داخل الفترة (إيجار/مرتبات/…) ناقصها من صافي الربح
  var expRows = readSheet(getSheet(SHEET_EXPENSES));
  var totalExpenses = 0;
  for (var ex = 1; ex < expRows.length; ex++) {
    var eDate = toDate(expRows[ex][1]);
    if (eDate && eDate >= from && eDate <= to) totalExpenses += (Number(expRows[ex][4]) || 0);
  }

  return jsonOk({
    count: count,
    totalSales: totalSales,
    totalDiscount: totalDiscount,
    totalTax: totalTax,
    totalProfit: totalProfit,
    totalCostOfSold: totalCostOfSold,
    totalInventoryCost: totalInventoryCost,
    totalExpenses: totalExpenses,
    netProfit: totalProfit - totalExpenses,
    topProducts: topProducts,
    dailySales: dailyArray,
    from: formatDate(from),
    to: formatDate(to)
  });
}

/**
 * ====== تقرير ديون العملاء (الآجل) ======
 */
function handleGetDebtReport(body, userCheck) {
  if (!hasPermission(userCheck, 'customers')) return jsonError('لا تملك صلاحية عرض العملاء');

  var custSheet = getSheet(SHEET_CUSTOMERS);
  var custRows = readSheet(custSheet);

  // قراءة فواتير الآجل غير المسددة من المبيعات
  var salesSheet = getSheet(SHEET_SALES);
  var salesRows = readSheet(salesSheet);
  var headers = ['invoiceNo', 'date', 'time', 'cashier', 'customer', 'subtotal', 'discount', 'tax', 'total', 'paid', 'balance', 'paymentMethod', 'status'];

  // تفاصيل الآجل (بيانات الضامن...)
  var cdSheet = getSheet(SHEET_CREDIT_DETAILS);
  var cdRows = readSheet(cdSheet);
  var cdHeaders = ['invoiceNo', 'customer', 'phone', 'address', 'idNumber', 'guarantorName', 'guarantorAddress', 'guarantorPhone', 'amount', 'date'];
  var cdByInvoice = {};
  for (var q = 1; q < cdRows.length; q++) {
    var cd = {};
    for (var c = 0; c < cdHeaders.length; c++) cd[cdHeaders[c]] = cdRows[q][c];
    cdByInvoice[cd.invoiceNo] = cd;
  }

  // قراءة المرتجعات لتحديد فواتير الاسترجاع الكلي/الجزئي وحساب قيمتها
  var retSheet2 = getSheet(SHEET_RETURNS);
  var retRows2 = readSheet(retSheet2);
  var retMap = {}; // invoiceNo -> { returned: 0, exchanged: 0 }
  for (var rr = 1; rr < retRows2.length; rr++) {
    if (!retRows2[rr] || !retRows2[rr][1]) continue;
    var rInv = String(retRows2[rr][1]);
    if (!retMap[rInv]) retMap[rInv] = { returned: 0, exchanged: 0 };
    var rType = String(retRows2[rr][8] || '');
    var rTot = Number(retRows2[rr][6]) || 0;
    if (rType === 'استرجاع') retMap[rInv].returned += rTot;
    else if (rType === 'استبدال') retMap[rInv].exchanged += rTot;
  }

  // تجميع الفواتير الآجلة لكل عميل (مع خصم المرتجعات من الأرصدة)
  var debtMap = {}; // name -> { totalDue, invoices: [] }
  for (var i = 1; i < salesRows.length; i++) {
    var sale = salesRows[i];
    if (!sale) continue;
    var invoiceStatus = String(sale[12] || '');
    if (invoiceStatus === 'مرجوع') continue; // فاتورة مُرجعة بالكامل: لا دين عليها
    var pm = String(sale[11] || '');
    var bal = Number(sale[10]) || 0;
    if (bal <= 0) continue;
    var custName = String(sale[4] || '');
    if (!custName) continue;
    // خصم قيمة الاسترجاع الجزئي من الرصيد المتبقي للفاتورة
    // (قيمة المرتجع تُسوّي الدين على الفاتورة أولاً قبل أي تسوية آجلة / رد نقدي)
    var rInfo = retMap[String(sale[0])] || { returned: 0, exchanged: 0 };
    var offset = Math.min(bal, rInfo.returned);
    var effBalance = Math.max(bal - offset, 0);
    if (effBalance <= 0 && invoiceStatus === 'استرجاع جزئي') continue; // سُدّد بالكامل بالمرتجع
    if (!debtMap[custName]) debtMap[custName] = { totalDue: 0, invoices: [] };
    var detail = cdByInvoice[sale[0]] || {};
    debtMap[custName].invoices.push({
      invoiceNo: sale[0],
      date: sale[1],
      time: sale[2],
      total: Number(sale[8]) || 0,
      paid: Number(sale[9]) || 0,
      balance: effBalance,
      rawBalance: bal,
      status: invoiceStatus,
      returned: rInfo.returned,
      exchanged: rInfo.exchanged,
      phone: detail.phone || '',
      address: detail.address || '',
      idNumber: detail.idNumber || '',
      guarantorName: detail.guarantorName || '',
      guarantorAddress: detail.guarantorAddress || '',
      guarantorPhone: detail.guarantorPhone || ''
    });
    debtMap[custName].totalDue += effBalance;
  }

  // قائمة العملاء برصيدهم الحالي (من ورقة العملاء = المرجع الأساسي)
  var customers = [];
  for (var z = 1; z < custRows.length; z++) {
    customers.push({
      id: custRows[z][0],
      name: custRows[z][1],
      phone: custRows[z][2],
      address: custRows[z][3],
      debt: Number(custRows[z][4]) || 0,
      creditLimit: Number(custRows[z][5]) || 0
    });
  }

  // دمج: أعمدة العملاء + تفاصيل الفواتير
  customers.forEach(function (c) {
    if (!c.name) return;
    var d = debtMap[c.name] || { totalDue: 0, invoices: [] };
    c.creditInvoices = d.invoices;
    // رصيد العميل نفسه هو المرجع (يتحدث تلقائياً مع المرتجعات)
    var custDebt = Number(c.debt) || 0;
    c.totalDue = custDebt;
    // عميل مسدّد بالكامل لكن له أرصدة فعلية في فواتيره (بيانات قديمة): نحسبها
    if (custDebt === 0 && d.totalDue > 0) c.totalDue = d.totalDue;
    // أقدم تاريخ فاتورة غير مسددة = موعد التحصيل
    var oldest = null;
    (d.invoices || []).forEach(function (inv) {
      if (inv.balance > 0 && inv.date) {
        if (!oldest || inv.date < oldest) oldest = inv.date;
      }
    });
    c.oldestDueDate = oldest || '';
  });

  var totalDebt = 0;
  customers.forEach(function (c) { totalDebt += c.totalDue; });

  return jsonOk({ customers: customers, totalDebt: totalDebt, count: customers.filter(function (c) { return c.totalDue > 0; }).length });
}

/**
 * ====== الاسترجاع والاستبدال ======
 */
function handleGetReturns(body) {
  var sh = getSheet(SHEET_RETURNS);
  var rows = readSheet(sh);
  var headers = ['returnNo', 'invoiceNo', 'date', 'productId', 'qty', 'price', 'total', 'name', 'type', 'paymentMethod', 'cashier', 'status'];
  var items = rowsToObjects(rows, headers);
  items.forEach(function (it) {
    it.qty = Number(it.qty) || 0;
    it.price = Number(it.price) || 0;
    it.total = Number(it.total) || 0;
  });
  if (body && body.invoiceNo) {
    var target = String(body.invoiceNo);
    items = items.filter(function (x) { return String(x.invoiceNo) === target; });
  }
  return jsonOk(items);
}

// حذف سجل استرجاع/استبدال من سجل المرتجعات (صلاحية الادمن)
function handleDeleteReturn(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية حذف سجلات المرتجعات');
  var returnNo = String(body.returnNo || '');
  if (!returnNo) return jsonError('رقم الاسترجاع مطلوب');
  var sh = getSheet(SHEET_RETURNS);
  var rows = readSheet(sh);
  var matched = false;
  var productsSheet = getSheet(SHEET_PRODUCTS);
  var productsRows = readSheet(productsSheet);
  var affected = {};

  // اجمع أثر السجلات على المخزون قبل الحذف:
  // - سجل 'استرجاع' كان أضاف الكمية للمخزون → تُخصم منه مجدداً
  // - سجل 'استبدال' كان خصم الكمية من المخزون → تُعاد إليه
  for (var i = rows.length - 1; i >= 1; i--) {
    if (String(rows[i][0]) !== returnNo) continue;
    matched = true;
    var pid = String(rows[i][3] || '');
    var qty = Number(rows[i][4]) || 0;
    var type = String(rows[i][8] || '');
    if (!pid || qty <= 0) continue;
    if (type === 'استرجاع') {
      affected[pid] = (affected[pid] || 0) - qty;
    } else if (type === 'استبدال') {
      affected[pid] = (affected[pid] || 0) + qty;
    }
  }
  if (!matched) return jsonOk({ ok: true, already: true }); // السجل محذوف سلفاً = نجاح (عكس أثر المخزون نفّذ سابقاً)

  // طبّق التعديلات على جدول المنتجات
  for (var pidKey in affected) {
    for (var pi = 1; pi < productsRows.length; pi++) {
      if (productsRows[pi][0] && String(productsRows[pi][0]) === pidKey) {
        var cur = Number(productsRows[pi][8]) || 0;
        productsSheet.getRange(pi + 1, 9).setValue(Math.max(0, cur + affected[pidKey]));
        break;
      }
    }
  }

  // احذف الصفوف (من الأسفل للأعلى)
  for (var j = rows.length - 1; j >= 1; j--) {
    if (String(rows[j][0]) === returnNo) sh.deleteRow(j + 1);
  }
  return jsonOk({ ok: true });
}

// إجراء استرجاع/استبدال لفاتورة بيع: يعيد الكميات للمخزون، يسجل صفوف المرتجع،
// ويحسب المبلغ المردود للعميل أو المبلغ المطلوب دفعه (فرق الاستبدال).
function handleReturnSale(body, userCheck) {
  if (!hasPermission(userCheck, 'returns')) return jsonError('لا تملك صلاحية إجراء عمليات الاسترجاع');
  var invoiceNo = String(body.invoiceNo || '');
  var returned = body.returned || [];
  var exchanged = body.exchanged || [];
  if (!returned.length) return jsonError('اختر أصنافاً للاسترجاع أولاً');

  var salesSheet = getSheet(SHEET_SALES);
  var salesRows = readSheet(salesSheet);
  var saleLine = -1, customer = '', paymentMethod = '', balance = 0, status = '';
  for (var i = 1; i < salesRows.length; i++) {
    if (salesRows[i][0] && String(salesRows[i][0]) === invoiceNo) {
      saleLine = i;
      customer = String(salesRows[i][4] || '');
      paymentMethod = String(salesRows[i][11] || '');
      status = String(salesRows[i][12] || '');
      balance = Number(salesRows[i][10]) || 0;
      break;
    }
  }
  if (saleLine === -1) return jsonOk({ ok: true, already: true }); // الفاتورة غير موجودة (حُذفت/سبق معالجتها) = نجاح تخطي

  // بنود الفاتورة الأصلية للتحقق من الكميات المسموح بإرجاعها
  var itemsSheet = getSheet(SHEET_SALE_ITEMS);
  var itemsRows = readSheet(itemsSheet);

  // كمية المرتجَع سابقاً لكل منتج من هذه الفاتورة
  var retSheet = getSheet(SHEET_RETURNS);
  var retRows = readSheet(retSheet);
  var prevRet = {};
  for (var r = 1; r < retRows.length; r++) {
    if (retRows[r][1] && String(retRows[r][1]) === invoiceNo && String(retRows[r][8]) === 'استرجاع') {
      var pid = String(retRows[r][3]);
      prevRet[pid] = (prevRet[pid] || 0) + (Number(retRows[r][4]) || 0);
    }
  }

  // الـ returnNo يُولَّد من العميل إن أُرسل، مع منع تكرار التطبيق (idempotency)
  // حتى لا تتضاعف الكميات في المخزون عند إعادة محاولة المزامنة أو فقدان الاستجابة.
  var returnNo = String(body.returnNo || ('R' + String(Date.now()).slice(-8)));
  for (var dr = 1; dr < retRows.length; dr++) {
    if (String(retRows[dr][0]) === returnNo) return jsonOk({ ok: true, already: true });
  }
  var dateStr = formatDate(new Date());
  var cashier = body.cashier || userCheck.name || '';
  var returnedValue = 0;

  // نسبة الخصم/الضريبة على السلة: قيمة المرتجع تُحسب بصافي السعر الفعلي
  // (لو الفاتورة بخّصم 100 من 2000 فقيمة المرتجع النسبي = net/gross)
  var saleGross = Number(salesRows[saleLine][5]) || 0;
  var saleTotal = Number(salesRows[saleLine][8]) || 0;
  var retRatio = (saleGross > 0) ? (saleTotal / saleGross) : 1;

  var productsSheet = getSheet(SHEET_PRODUCTS);
  var productsRows = readSheet(productsSheet);

  // الأصناف المرتَجعة: إرجاعها للمخزون وتسجيلها
  for (var k = 0; k < returned.length; k++) {
    var rit = returned[k];
    var rpid = String(rit.productId || '');
    var rqty = Number(rit.qty) || 0;
    if (rqty <= 0) continue;
    var soldQty = 0, price = 0, name = '';
    for (var si = 1; si < itemsRows.length; si++) {
      if (itemsRows[si][0] && String(itemsRows[si][0]) === invoiceNo && itemsRows[si][1] && String(itemsRows[si][1]) === rpid) {
        soldQty = Number(itemsRows[si][3]) || 0;
        price = Number(itemsRows[si][4]) || 0;
        name = String(itemsRows[si][2] || '');
        break;
      }
    }
    if (soldQty > 0 && (prevRet[rpid] || 0) + rqty > soldQty) return jsonError('كمية الاسترجاع تتجاوز المباع للفاتورة: ' + (name || rpid));
    var found = false;
    for (var pi = 1; pi < productsRows.length; pi++) {
      if (productsRows[pi][0] && String(productsRows[pi][0]) === rpid) {
        productsSheet.getRange(pi + 1, 9).setValue((Number(productsRows[pi][8]) || 0) + rqty);
        productsRows = readSheet(productsSheet);
        found = true;
        break;
      }
    }
    if (!found) return jsonError('المنتج غير موجود بالمخزون: ' + rpid);
    prevRet[rpid] = (prevRet[rpid] || 0) + rqty;
    var lineRaw = rqty * price;
    var lineVal = Math.round(lineRaw * retRatio * 100) / 100;
    returnedValue += lineVal;
    addRow(retSheet, [returnNo, invoiceNo, dateStr, rpid, rqty, price, lineVal, name, 'استرجاع', paymentMethod, cashier, 'مكتمل']);
  }

  // بنود الاستبدال: صرف منتجات جديدة وخصمها من المخزون
  var exchangedValue = 0;
  for (var m = 0; m < exchanged.length; m++) {
    var eit = exchanged[m];
    var epid = String(eit.productId || '');
    var eqty = Number(eit.qty) || 0;
    if (eqty <= 0) continue;
    var eName = '', ePrice = Number(eit.price) || 0;
    var eFound = false;
    for (var epi = 1; epi < productsRows.length; epi++) {
      if (productsRows[epi][0] && String(productsRows[epi][0]) === epid) {
        eName = String(productsRows[epi][1] || '');
        eFound = true;
        var stock = Number(productsRows[epi][8]) || 0;
        if (eqty > stock) return jsonError('الكمية غير متوفرة للمنتج: ' + eName + ' (المتاح: ' + stock + ')');
        productsSheet.getRange(epi + 1, 9).setValue(stock - eqty);
        productsRows = readSheet(productsSheet);
        break;
      }
    }
    if (!eFound) return jsonError('المنتج غير موجود: ' + epid);
    if (!ePrice) ePrice = Number(eit.price) || 0;
    exchangedValue += eqty * ePrice;
    addRow(retSheet, [returnNo, invoiceNo, dateStr, epid, eqty, ePrice, eqty * ePrice, eName, 'استبدال', paymentMethod, cashier, 'مكتمل']);
  }

  var diff = exchangedValue - returnedValue;
  var settle = body.paymentMethod || paymentMethod;
  var salePhone = (salesRows[saleLine] && salesRows[saleLine][13] !== undefined) ? salesRows[saleLine][13] : '';

  // التسوية المالية: قيمة المرتجع تسدد أولاً المتبقي على الفاتورة الأصلية،
  // ثم تدفع قيمة البديل، وما يتبقى يُرد نقداً للعميل.
  var usedForOld = Math.min(balance, returnedValue);
  var creditAfterOld = returnedValue - usedForOld; // ما تبقى من قيمة المرتجع بعد تسديد دين الفاتورة القديمة
  var dueNow = exchangedValue - creditAfterOld;   // المطلوب من العميل (فرق الاستبدال بعد خصم قيمة المرتجع ودين الفاتورة)

  // منع التسوية الآجلة عندما يكون للعميل مبلغ مردود نقداً (قيمة المرتجع أكبر من البديل)
  if (settle === 'آجل / دين' && creditAfterOld > exchangedValue) {
    return jsonError('لا يمكن تسوية العملية آجلاً لأن قيمة المرتجع أكبر من البديل - المبلغ مردود للعميل نقداً');
  }

  var isCreditSettle = (settle === 'آجل / دين');
  var refund = isCreditSettle ? 0 : Math.max(-dueNow, 0);  // مردود نقدي للعميل
  var collect = isCreditSettle ? 0 : Math.max(dueNow, 0);   // مطلوب من العميل نقداً
  var newOwed = isCreditSettle ? Math.max(dueNow, 0) : 0;   // دين يُسجَّل على العميل (آجل)
  var returnedOffset = usedForOld;
  var netDebtChange = newOwed - usedForOld;

  // المتبقي غير المسدد على فاتورة الاستبدال الجديدة (آجل): يُسجَّل في حساب العميل
  var exPaid = isCreditSettle ? 0 : collect;
  var exBalance = isCreditSettle ? newOwed : 0;

  // تسوية رصيد العميل في حسابه (دفاتر الآجل):
  // - المرتجع يُخفض ما عليه من الفاتورة القديمة
  // - المتبقي من فاتورة الاستبدال (آجل / دين) يُضاف كدين جديد على العميل
  var isCreditSale = (paymentMethod === 'آجل / دين') || (balance > 0);
  if (customer && (isCreditSale || netDebtChange !== 0)) {
    var custSheet = getSheet(SHEET_CUSTOMERS);
    var custRows = readSheet(custSheet);
    var cuIdx = -1;
    for (var c = 1; c < custRows.length; c++) {
      if (custRows[c][1] && String(custRows[c][1]) === customer) { cuIdx = c; break; }
    }
    if (cuIdx === -1) {
      var newCustId = 'C' + Date.now().toString().slice(-6);
      addRow(custSheet, [newCustId, customer, salePhone, '', newOwed, 0, new Date().toISOString()]);
    } else {
      var curDebt = Number(custRows[cuIdx][4]) || 0;
      // الرصيد يقبل السالب: المرتجع قد يجعل للعميل رصيداً لدينا
      custSheet.getRange(cuIdx + 1, 5).setValue(curDebt + netDebtChange);
    }
  }

  // تحديث حالة الفاتورة (مرجوع بالكامل / استرجاع جزئي)
  var allReturned = true;
  for (var ai = 1; ai < itemsRows.length; ai++) {
    if (itemsRows[ai][0] && String(itemsRows[ai][0]) === invoiceNo) {
      var apid = String(itemsRows[ai][1] || '');
      var aq = Number(itemsRows[ai][3]) || 0;
      if (aq > 0 && (prevRet[apid] || 0) < aq) { allReturned = false; break; }
    }
  }
  var newStatus = allReturned ? 'مرجوع' : (returnedValue > 0 ? 'استرجاع جزئي' : status);
  if (newStatus !== status) salesSheet.getRange(saleLine + 1, 13).setValue(newStatus);

  // إنشاء فاتورة استبدال جديدة في المبيعات: تظهر في صفحة المبيعات والتقارير
  // بقيمة البديل (هو بكام) والمرتجع من الفاتورة القديمة (كان كم) والمسترد للعميل (خد كام)
  var newInvoiceNo = '';
  if (exchangedValue > 0) {
    if (body.newInvoiceNo) {
      // رقم فاتورة بديل يُوصَل من العميل لمنع التكرار عند إعادة محاولة المزامنة
      newInvoiceNo = String(body.newInvoiceNo);
      for (var es1 = 1; es1 < salesRows.length; es1++) {
        if (salesRows[es1][0] && String(salesRows[es1][0]) === newInvoiceNo) return jsonOk({ ok: true, already: true });
      }
    } else {
      newInvoiceNo = 'F' + String(Date.now());
      var noDup = true;
      while (noDup) {
        noDup = false;
        for (var es2 = 1; es2 < salesRows.length; es2++) {
          if (salesRows[es2][0] && String(salesRows[es2][0]) === newInvoiceNo) {
            noDup = true; newInvoiceNo = 'F' + String(Date.now()); break;
          }
        }
      }
    }
    addRow(salesSheet, [
      newInvoiceNo, formatDate(new Date()), formatTime(new Date()),
      cashier, customer, exchangedValue, 0, 0, exchangedValue, exPaid, exBalance,
      settle, 'استبدال', salePhone, returnedValue, refund
    ]);
    // بنود فاتورة الاستبدال (لتفاصيل الفاتورة وبحث المنتجات)
    var newItemsSheet = getSheet(SHEET_SALE_ITEMS);
    for (var ei = 0; ei < exchanged.length; ei++) {
      var exi = exchanged[ei];
      if (!((Number(exi.qty) || 0) > 0)) continue;
      var exCost = 0, exItemName = String(exi.name || '');
      for (var expi = 1; expi < productsRows.length; expi++) {
        if (productsRows[expi][0] && String(productsRows[expi][0]) === String(exi.productId || '')) {
          exCost = Number(productsRows[expi][7]) || 0;
          if (!exItemName) exItemName = String(productsRows[expi][1] || '');
          break;
        }
      }
      addRow(newItemsSheet, [
        newInvoiceNo, String(exi.productId || ''), exItemName, Number(exi.qty) || 0,
        Number(exi.price) || 0, (Number(exi.qty) || 0) * (Number(exi.price) || 0), exCost
      ]);
    }
    // تسجيل تفاصيل الآجل لفاتورة الاستبدال في حساب العميل (تظهر في "حسابات الآجل")
    if (newOwed > 0 && customer) {
      var cdSheet = getSheet(SHEET_CREDIT_DETAILS);
      var cdRows = readSheet(cdSheet);
      var cd = null;
      for (var dci = 1; dci < cdRows.length; dci++) {
        if (cdRows[dci][0] && String(cdRows[dci][0]) === invoiceNo) { cd = cdRows[dci]; break; }
      }
      // بيانات إضافية للآجل قابلة للإدخال من شاشة الاسترجاع (هاتف/عنوان/بطاقة/ضامن)
      var cdPhone = (body.cdPhone !== undefined && body.cdPhone !== null && String(body.cdPhone) !== '')
        ? String(body.cdPhone) : ((cd && cd[2]) || salePhone);
      addRow(cdSheet, [
        newInvoiceNo, customer,
        cdPhone,
        (body.cdAddress !== undefined && body.cdAddress !== null) ? String(body.cdAddress) : ((cd && cd[3]) || ''),
        (body.cdCardNo !== undefined && body.cdCardNo !== null) ? String(body.cdCardNo) : ((cd && cd[4]) || ''),
        (body.cdGuarantor !== undefined && body.cdGuarantor !== null) ? String(body.cdGuarantor) : ((cd && cd[5]) || ''),
        (body.cdGuarantorAddress !== undefined && body.cdGuarantorAddress !== null) ? String(body.cdGuarantorAddress) : ((cd && cd[6]) || ''),
        (body.cdGuarantorPhone !== undefined && body.cdGuarantorPhone !== null) ? String(body.cdGuarantorPhone) : ((cd && cd[7]) || ''),
        newOwed, formatDate(new Date())
      ]);
    }
  }

  return jsonOk({ ok: true, returnNo: returnNo, refund: refund, collect: collect, returnedValue: returnedValue, exchangedValue: exchangedValue, newInvoiceNo: newInvoiceNo, owed: newOwed });
}

/**
 * ====== الأرشيف ======
 * أرشفة فاتورة = نسخها إلى ورقة "الأرشيف" وإزالتها من المبيعات (بدون لمس المخزون).
 */

function handleGetArchive(body, userCheck) {
  if (!hasPermission(userCheck, 'reports')) return jsonError('لا تملك صلاحية عرض الأرشيف');
  var sh = getSheet(SHEET_ARCHIVE);
  var rows = readSheet(sh);
  var out = [];
  for (var i = 1; i < rows.length; i++) {
    var r = rows[i];
    out.push({
      id: String(r[0] || ''), date: String(r[1] || ''), invoiceNo: String(r[2] || ''),
      customer: String(r[3] || ''), total: Number(r[4]) || 0, paid: Number(r[5]) || 0,
      cashier: String(r[6] || ''), archivedAt: String(r[7] || ''),
      payload: r[8] !== undefined ? String(r[8]) : '', notes: String(r[9] || '')
    });
  }
  return jsonOk(out);
}

function archiveSaleRow(salesSheet, salesRows, i, archiveSheet) {
  var r = salesRows[i];
  var row = r.slice ? r.slice() : r;
  var rec = {
    invoiceNo: String(row[0] || ''), date: String(row[1] || ''), time: String(row[2] || ''),
    cashier: String(row[3] || ''), customer: String(row[4] || ''), subtotal: Number(row[5]) || 0,
    discount: Number(row[6]) || 0, tax: Number(row[7]) || 0, total: Number(row[8]) || 0,
    paid: Number(row[9]) || 0, balance: Number(row[10]) || 0, paymentMethod: String(row[11] || ''),
    status: String(row[12] || ''), customerPhone: String(row[13] || ''),
    exchangeCredit: Number(row[14]) || 0, refund: Number(row[15]) || 0
  };
  // أرشفة بنود الفاتورة
  var itSheet = getSheet(SHEET_SALE_ITEMS);
  var itRows = readSheet(itSheet);
  var items = [];
  for (var j = 1; j < itRows.length; j++) {
    if (String(itRows[j][0]) === rec.invoiceNo) {
      items.push({ productId: String(itRows[j][1] || ''), name: String(itRows[j][2] || ''), qty: Number(itRows[j][3]) || 0, price: Number(itRows[j][4]) || 0 });
    }
  }
  rec.items = items;

  addRow(archiveSheet, [
    'A' + String(Date.now()), rec.date, rec.invoiceNo, rec.customer, rec.total, rec.paid,
    rec.cashier, formatDate(new Date()), JSON.stringify(rec), ''
  ]);

  // إزالة بنود الفاتورة من "بنود المبيعات"
  for (var d = itRows.length - 1; d >= 1; d--) {
    if (String(itRows[d][0]) === rec.invoiceNo) itSheet.deleteRow(d + 1);
  }
  // إزالة الفاتورة نفسها من "المبيعات"
  salesSheet.deleteRow(i + 1);
  return rec.invoiceNo;
}

function handleArchiveSale(body, userCheck) {
  if (!hasPermission(userCheck, 'reports')) return jsonError('لا تملك صلاحية أرشفة الفواتير');
  var invoiceNo = (body.invoiceNo || '').toString();
  if (!invoiceNo) return jsonError('رقم الفاتورة مطلوب');
  var salesSheet = getSheet(SHEET_SALES);
  var salesRows = readSheet(salesSheet);
  for (var i = 1; i < salesRows.length; i++) {
    if (salesRows[i][0] && salesRows[i][0].toString() === invoiceNo) {
      var bal = Number(salesRows[i][10]) || 0;
      if (bal > 0) return jsonError('لا يمكن أرشفة فاتورة غير مسددة بالكامل (الباقي: ' + bal + ')');
      var archivedNo = archiveSaleRow(salesSheet, salesRows, i, getSheet(SHEET_ARCHIVE));
      return jsonOk({ ok: true, invoiceNo: archivedNo });
    }
  }
  // الفاتورة غير موجودة بالمبيعات: إما محذوفة أو سبق أرشفتها = نجاح بدل التعليق في الصف
  return jsonOk({ ok: true, invoiceNo: invoiceNo, already: true });
}

function handleDeleteArchive(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية حذف سجلات الأرشيف');
  var id = (body.id || '').toString();
  if (!id) return jsonError('المعرف مطلوب');
  var sh = getSheet(SHEET_ARCHIVE);
  var rows = readSheet(sh);
  var found = false;
  for (var i = rows.length - 1; i >= 1; i--) {
    if (String(rows[i][0]) === id) { sh.deleteRow(i + 1); found = true; break; }
  }
  if (!found) return jsonOk({ ok: true, already: true }); // محذوف سلفاً = نجاح (حذف لا يحتمل التكرار)
  return jsonOk({ ok: true });
}

/**
 * ====== نسخة احتياطية كاملة (تصدير/استيراد) ======
 */
var BACKUP_HEADERS = {
  users: 'الاسم,كلمة المرور,الدور,الصلاحيات'.split(','),
  products: 'معرف المنتج,الاسم,كود الباركود,قسم,سعر البيع,سعر الجملة,سعر نصف الجملة,سعر التكلفة,الكمية,الحد الأدنى,تاريخ الإضافة,الحالة'.split(','),
  sales: 'رقم الفاتورة,التاريخ,الوقت,الكاشير,العميل,الإجمالي,الخصم,الضريبة,الصافي,المدفوع,الباقي,طريقة الدفع,الحالة,هاتف العميل,المرتجع من الاستبدال,مسترد للعميل'.split(','),
  saleItems: 'رقم الفاتورة,معرف المنتج,اسم المنتج,الكمية,سعر الوحدة,الإجمالي,سعر التكلفة,السعر الأساسي'.split(','),
  customers: 'معرف العميل,الاسم,الهاتف,العنوان,رصيد مدين,حد الائتمان,تاريخ الإضافة'.split(','),
  creditDetails: 'رقم الفاتورة,العميل,الهاتف,العنوان,رقم البطاقة,اسم الضامن,عنوان الضامن,هاتف الضامن,المبلغ,التاريخ'.split(','),
  payments: 'معرف العميل,الاسم,المبلغ,التاريخ,الكاشير'.split(','),
  suppliers: 'معرف المورد,الاسم,الهاتف,العنوان,الملاحظات,رصيد لنا عند المورد'.split(','),
  supplierPayments: 'معرف,المورد,التاريخ,الوقت,النوع,المبلغ,ملاحظات,الكاشير,رقم الشراء'.split(','),
  purchases: 'رقم الشراء,التاريخ,المورد,الإجمالي,المدفوع,المتبقي,الكاشير,الحالة'.split(','),
  purchaseItems: 'رقم الشراء,معرف المنتج,اسم المنتج,الكمية,سعر الشراء,الإجمالي'.split(','),
  purchaseReturns: 'رقم المرتجع,رقم الشراء,التاريخ,معرف المنتج,اسم المنتج,الكمية,سعر الوحدة,الإجمالي,المورد,الكاشير,الحالة'.split(','),
  returns: 'رقم الاسترجاع,رقم الفاتورة,التاريخ,معرف المنتج,الكمية,سعر الوحدة,الإجمالي,اسم المنتج,النوع,طريقة الدفع,الكاشير,الحالة'.split(','),
  settings: 'المفتاح,القيمة'.split(','),
  archive: 'المعرف,التاريخ,رقم الفاتورة,العميل,الإجمالي,المدفوع,الكاشير,تاريخ الحفظ,البيانات,ملاحظات'.split(','),
  expenses: 'معرف المصروف,التاريخ,الكاشير,النوع,المبلغ,ملاحظات'.split(',')
};

function handleGetAllData(body, userCheck) {
  var out = { products: [], categories: [], customers: [], suppliers: [], sales: [], saleItems: [], purchases: [], purchaseItems: [], purchaseReturns: [], payments: [], creditDetails: [], returns: [], archive: [], expenses: [], settings: {} };

  // المنتجات
  var pRows = readSheet(getSheet(SHEET_PRODUCTS));
  var pHeaders = ['id', 'name', 'barcode', 'category', 'sellPrice', 'wholesalePrice', 'semiPrice', 'costPrice', 'quantity', 'minQuantity', 'addedDate', 'status'];
  var products = rowsToObjects(pRows, pHeaders);
  products.forEach(function (p) {
    p.id = String(p.id); p.barcode = String(p.barcode);
    for (var k in p) {
      var v = p[k];
      if (typeof v === 'string' && v !== '' && !isNaN(Number(v)) && k !== 'name' && k !== 'id' && k !== 'category' && k !== 'barcode' && k !== 'addedDate' && k !== 'status') p[k] = Number(v);
    }
    p.quantity = Number(p.quantity) || 0;
    p.lowStock = p.quantity <= (Number(p.minQuantity) || 0);
  });
  out.products = products;

  // الأقسام
  var cRows = readSheet(getSheet(SHEET_CATEGORIES));
  var cats = [];
  for (var ci = 1; ci < cRows.length; ci++) if (cRows[ci][0]) cats.push(String(cRows[ci][0]));
  out.categories = cats;

  // العملاء
  var cuRows = readSheet(getSheet(SHEET_CUSTOMERS));
  var cuHeaders = ['id', 'name', 'phone', 'address', 'debt', 'creditLimit', 'addedDate'];
  var customers = rowsToObjects(cuRows, cuHeaders);
  customers.forEach(function (c) { c.debt = Number(c.debt) || 0; c.creditLimit = Number(c.creditLimit) || 0; });
  out.customers = customers;

  // الموردين (مع حساب ديون المشتريات)
  var sRows = readSheet(getSheet(SHEET_SUPPLIERS));
  var sHeaders = ['id', 'name', 'phone', 'address', 'notes', 'credit'];
  var suppliers = rowsToObjects(sRows, sHeaders);
  var prRows = readSheet(getSheet(SHEET_PURCHASES));
  var suppMap = {};
  for (var psi = 1; psi < prRows.length; psi++) {
    if (!prRows[psi]) continue;
    var sname = String(prRows[psi][2] || '');
    if (!sname) continue;
    if (!suppMap[sname]) suppMap[sname] = { purchased: 0, paid: 0, remaining: 0, lastDate: '' };
    var t = Number(prRows[psi][3]) || 0, pa = Number(prRows[psi][4]) || 0, re = Number(prRows[psi][5]) || 0;
    suppMap[sname].purchased += t; suppMap[sname].paid += pa; suppMap[sname].remaining += re;
    if (String(prRows[psi][1] || '') > suppMap[sname].lastDate) suppMap[sname].lastDate = String(prRows[psi][1] || '');
  }
  var allLedger = supplierLedgerTotals();
  suppliers.forEach(function (s) {
    var m = suppMap[s.name] || { purchased: 0, paid: 0, remaining: 0, lastDate: '' };
    var ld = allLedger[s.name] || { debt: 0, paid: 0, count: 0 };
    s.debt = m.remaining; s.totalPurchased = m.purchased; s.totalPaid = m.paid; s.lastPurchaseDate = m.lastDate;
    s.manualDebt = ld.debt; s.ledgerPayments = ld.paid; s.ledgerCount = ld.count;
    s.credit = Number(s.credit) || 0;
    s.netBalance = m.remaining + ld.debt - ld.paid - s.credit;
  });
  out.suppliers = suppliers;
  out.supplierPayments = rowsToObjects(readSheet(getSheet(SHEET_SUPPLIER_PAYMENTS)), ['id', 'supplier', 'date', 'time', 'type', 'amount', 'notes', 'cashier', 'purchaseNo']);

  // المبيعات
  var slRows = readSheet(getSheet(SHEET_SALES));
  var slHeaders = ['invoiceNo', 'date', 'time', 'cashier', 'customer', 'subtotal', 'discount', 'tax', 'total', 'paid', 'balance', 'paymentMethod', 'status', 'customerPhone', 'exchangeCredit', 'refund'];
  var sales = rowsToObjects(slRows, slHeaders);
  sales.forEach(function (s) {
    s.subtotal = Number(s.subtotal); s.discount = Number(s.discount); s.tax = Number(s.tax);
    s.total = Number(s.total); s.paid = Number(s.paid); s.balance = Number(s.balance);
  });
  out.sales = sales;

  // بنود المبيعات
  var itRows = readSheet(getSheet(SHEET_SALE_ITEMS));
  var itHeaders = ['invoiceNo', 'productId', 'name', 'qty', 'price', 'total', 'cost', 'basePrice'];
  var items = rowsToObjects(itRows, itHeaders);
  items.forEach(function (s) { s.qty = Number(s.qty); s.price = Number(s.price); s.total = Number(s.total); s.cost = Number(s.cost); s.basePrice = (s.basePrice && s.basePrice !== '') ? Number(s.basePrice) : s.price; });
  out.saleItems = items;

  // المشتريات
  var puRows = readSheet(getSheet(SHEET_PURCHASES));
  var puHeaders = ['purchaseNo', 'date', 'supplier', 'total', 'paid', 'remaining', 'cashier', 'status'];
  var purchases = rowsToObjects(puRows, puHeaders);
  purchases.forEach(function (p) { p.total = Number(p.total); p.paid = Number(p.paid); p.remaining = Number(p.remaining); });
  out.purchases = purchases;

  // بنود المشتريات
  var piRows = readSheet(getSheet(SHEET_PURCHASE_ITEMS));
  var piHeaders = ['purchaseNo', 'productId', 'name', 'qty', 'price', 'total'];
  var pItems = rowsToObjects(piRows, piHeaders);
  pItems.forEach(function (it) { it.qty = Number(it.qty); it.price = Number(it.price); it.total = Number(it.total); });
  out.purchaseItems = pItems;

  // مرتجع المشتريات
  var prtRows = readSheet(getSheet(SHEET_PURCHASE_RETURNS));
  var prtHeaders = ['returnNo', 'purchaseNo', 'date', 'productId', 'name', 'qty', 'price', 'total', 'supplier', 'cashier', 'status'];
  var pRets = rowsToObjects(prtRows, prtHeaders);
  pRets.forEach(function (r) { r.qty = Number(r.qty) || 0; r.price = Number(r.price) || 0; r.total = Number(r.total) || 0; });
  out.purchaseReturns = pRets;

  // الدفعات
  var pmRows = readSheet(getSheet(SHEET_PAYMENTS));
  var pmHeaders = ['customerId', 'name', 'amount', 'date', 'cashier'];
  out.payments = rowsToObjects(pmRows, pmHeaders);

  // تفاصيل الآجل
  var cdRows = readSheet(getSheet(SHEET_CREDIT_DETAILS));
  var cdHeaders = ['invoiceNo', 'customer', 'phone', 'address', 'idNumber', 'guarantorName', 'guarantorAddress', 'guarantorPhone', 'amount', 'date'];
  out.creditDetails = rowsToObjects(cdRows, cdHeaders);

  // المرتجعات
  var rtRows = readSheet(getSheet(SHEET_RETURNS));
  var rtHeaders = ['returnNo', 'invoiceNo', 'date', 'productId', 'qty', 'price', 'total', 'name', 'type', 'paymentMethod', 'cashier', 'status'];
  var rets = rowsToObjects(rtRows, rtHeaders);
  rets.forEach(function (r) { r.qty = Number(r.qty) || 0; r.price = Number(r.price) || 0; r.total = Number(r.total) || 0; });
  out.returns = rets;

  // الإعدادات
  var setRows = readSheet(getSheet(SHEET_SETTINGS));
  var settings = {};
  for (var si2 = 1; si2 < setRows.length; si2++) settings[setRows[si2][0]] = setRows[si2][1];
  out.settings = settings;

  // الأرشيف
  var arRows = readSheet(getSheet(SHEET_ARCHIVE));
  var arHeaders = ['id', 'date', 'invoiceNo', 'customer', 'total', 'paid', 'cashier', 'archivedDate', 'data', 'notes'];
  var archive = rowsToObjects(arRows, arHeaders);
  archive.forEach(function (a) { a.total = Number(a.total) || 0; a.paid = Number(a.paid) || 0; });
  out.archive = archive;

  // المصاريف
  var exRows = readSheet(getSheet(SHEET_EXPENSES));
  var exHeaders = ['id', 'date', 'cashier', 'type', 'amount', 'notes'];
  var expenses = rowsToObjects(exRows, exHeaders);
  expenses.forEach(function (ex) { ex.amount = Number(ex.amount) || 0; });
  out.expenses = expenses;

  return jsonOk(out);
}

function handleBackupExport(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية تصدير النسخة الاحتياطية');
  var out = {};
  Object.keys(BACKUP_HEADERS).forEach(function (key) {
    var sh = (key === 'sales') ? getSheet(SHEET_SALES) :
             (key === 'saleItems') ? getSheet(SHEET_SALE_ITEMS) :
             (key === 'creditDetails') ? getSheet(SHEET_CREDIT_DETAILS) :
             (key === 'purchaseItems') ? getSheet(SHEET_PURCHASE_ITEMS) :
             (key === 'purchaseReturns') ? getSheet(SHEET_PURCHASE_RETURNS) :
             (key === 'payments') ? getSheet(SHEET_PAYMENTS) :
             (key === 'users') ? getSheet(SHEET_USERS) :
             (key === 'customers') ? getSheet(SHEET_CUSTOMERS) :
             (key === 'suppliers') ? getSheet(SHEET_SUPPLIERS) :
             (key === 'supplierPayments') ? getSheet(SHEET_SUPPLIER_PAYMENTS) :
             (key === 'purchases') ? getSheet(SHEET_PURCHASES) :
             (key === 'returns') ? getSheet(SHEET_RETURNS) :
             (key === 'archive') ? getSheet(SHEET_ARCHIVE) :
             (key === 'expenses') ? getSheet(SHEET_EXPENSES) :
             (key === 'products') ? getSheet(SHEET_PRODUCTS) : getSheet(SHEET_SETTINGS);
    var rows = readSheet(sh);
    var arr = [];
    for (var i = 1; i < rows.length; i++) arr.push(rows[i].slice());
    out[key] = arr;
  });
  var catSheet = getSheet(SHEET_CATEGORIES);
  var catRows = readSheet(catSheet);
  var cats = [];
  for (var c = 1; c < catRows.length; c++) if (catRows[c][0]) cats.push(String(catRows[c][0]));
  out.categories = cats;
  return jsonOk(out);
}

function handleBackupImport(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية استيراد النسخة الاحتياطية');
  var keys = Object.keys(BACKUP_HEADERS);
  keys.forEach(function (key) {
    var sh = (key === 'sales') ? getSheet(SHEET_SALES) :
             (key === 'saleItems') ? getSheet(SHEET_SALE_ITEMS) :
             (key === 'creditDetails') ? getSheet(SHEET_CREDIT_DETAILS) :
             (key === 'purchaseItems') ? getSheet(SHEET_PURCHASE_ITEMS) :
             (key === 'purchaseReturns') ? getSheet(SHEET_PURCHASE_RETURNS) :
             (key === 'payments') ? getSheet(SHEET_PAYMENTS) :
             (key === 'users') ? getSheet(SHEET_USERS) :
             (key === 'customers') ? getSheet(SHEET_CUSTOMERS) :
             (key === 'suppliers') ? getSheet(SHEET_SUPPLIERS) :
             (key === 'supplierPayments') ? getSheet(SHEET_SUPPLIER_PAYMENTS) :
             (key === 'purchases') ? getSheet(SHEET_PURCHASES) :
             (key === 'returns') ? getSheet(SHEET_RETURNS) :
             (key === 'archive') ? getSheet(SHEET_ARCHIVE) :
             (key === 'expenses') ? getSheet(SHEET_EXPENSES) :
             (key === 'products') ? getSheet(SHEET_PRODUCTS) : getSheet(SHEET_SETTINGS);
    var data = (body[key] !== undefined && body[key] !== null) ? body[key] : [];
    if (!Array.isArray(data)) data = [];
    clearSheet(sh);
    setHeaders(sh, BACKUP_HEADERS[key]);
    data.forEach(function (r) {
      if (Array.isArray(r)) addRow(sh, r);
    });
  });
  var catData = Array.isArray(body.categories) ? body.categories : [];
  var catSheet = getSheet(SHEET_CATEGORIES);
  clearSheet(catSheet);
  setHeaders(catSheet, ['اسم القسم']);
  catData.forEach(function (x) { addRow(catSheet, [String(x)]); });
  return jsonOk({ ok: true });
}

// سجل عمليات النسخ الاحتياطي (append-only): كل عملية تُلحق صفاً جديداً ولا يُحذف
// أي صف أبداً، فتبقى حتى العمليات المحذوفة من النظام الأساسي قابلة للبحث هنا.
// كل عملية تحمل «معرف» فريداً (opId) يمنع تكرار الصف عند إعادة الإرسال.
function handleBackupOp(body, auth) {
  var headers = ['الوقت', 'المستخدم', 'العملية', 'البيانات', 'معرف'];
  var sh = getSheet(SHEET_OPLOG);
  if (sh.getLastRow() < 1) setHeaders(sh, headers);
  else {
    try {
      var cur = sh.getRange(1, 1, 1, 5).getValues()[0];
      if (String(cur[4] || '') !== 'معرف') sh.getRange(1, 5, 1, 1).setValue('معرف');
    } catch (err) {}
  }
  var opId = String(body.opId || '');
  if (opId) {
    var last = sh.getLastRow();
    if (last > 1) {
      var ids = sh.getRange(2, 5, last - 1, 1).getValues();
      for (var i = 0; i < ids.length; i++) {
        if (String(ids[i][0] || '') === opId) return jsonOk({ ok: true, dedup: true });
      }
    }
  }
  var ts = String(body.ts || '');
  var user = String(body.user || auth.user || '');
  var op = String(body.op || '');
  var data = body.data !== undefined ? String(body.data) : '';
  addRow(sh, [ts || formatDateTime(new Date()), user, op, data, opId]);
  return jsonOk({ ok: true });
}

// تحديث جداول الشيت الرئيسية (المرآة) بفارق عملية واحدة. العملية idempotent آمن:
// عند إعادة الإرسال تُحدَّث الصفوف بنفس القيم ولا يُضاف أي تكرار.
function handleBackupApply(body, auth) {
  if (!auth || !auth.role) return jsonError('غير مصرح به');
  var table = String(body.table || '');
  if (table === 'users') return jsonOk({ ok: true }); // لا نزامن كلمات المرور إلى المرآة أبداً
  var sheetMap = {
    products: SHEET_PRODUCTS, customers: SHEET_CUSTOMERS, suppliers: SHEET_SUPPLIERS,
    supplierPayments: SHEET_SUPPLIER_PAYMENTS,
    sales: SHEET_SALES, saleItems: SHEET_SALE_ITEMS, payments: SHEET_PAYMENTS,
    purchases: SHEET_PURCHASES, purchaseItems: SHEET_PURCHASE_ITEMS, purchaseReturns: SHEET_PURCHASE_RETURNS,
    creditDetails: SHEET_CREDIT_DETAILS, returns: SHEET_RETURNS, archive: SHEET_ARCHIVE,
    expenses: SHEET_EXPENSES, categories: SHEET_CATEGORIES, settings: SHEET_SETTINGS
  };
  var shName = sheetMap[table];
  if (!shName) return jsonError('جدول غير معروف');
  var keyMap = {
    users: [0], products: [0], sales: [0], saleItems: [0, 1], customers: [0], creditDetails: [0],
    payments: [0], suppliers: [0], supplierPayments: [0], purchases: [0], purchaseItems: [0, 1],
    purchaseReturns: [0], returns: [0], archive: [0], expenses: [0], categories: [0], settings: [0]
  };
  var keys = keyMap[table] || [0];
  var appendOnly = (table === 'payments');
  var headers = (table === 'categories') ? ['اسم القسم'] : (BACKUP_HEADERS[table] || null);
  if (!headers) return jsonError('جدول غير معروف');
  var sh = getSheet(shName);
  if (sh.getLastRow() < 1) setHeaders(sh, headers);
  var changes = parseRows(body.changes);
  var removed = parseRows(body.removed);
  var rows = [];
  try { rows = readSheet(sh); } catch (err) { rows = []; }
  var keyOf = function (r) {
    var a = (typeof r !== 'undefined' && r !== null && Object.prototype.toString.call(r) === '[object Array]') ? r : [r];
    var parts = [];
    for (var i = 0; i < keys.length; i++) parts.push(String(a[keys[i]] !== undefined ? a[keys[i]] : ''));
    return parts.join('\u0001');
  };
  var find = function (k) {
    for (var i = 1; i < rows.length; i++) {
      var r = rows[i];
      if (!r) continue;
      if (keyOf(r) === k) return i;
    }
    return -1;
  };
  // أولاً الحذف حسب المفتاح
  removed.forEach(function (rr) {
    var k = keyOf(rr);
    var ix = find(k);
    while (ix > 0) { rows.splice(ix, 1); ix = find(k); }
  });
  // ثم الإضافة/التعديل (upsert بالمفتاح، أو إلحاق للجداول التاريخية مثل الدفعات)
  changes.forEach(function (cr) {
    var row = (typeof cr !== 'undefined' && cr !== null && Object.prototype.toString.call(cr) === '[object Array]') ? cr.slice() : [cr];
    if (appendOnly) { rows.push(row); return; }
    var k = keyOf(row);
    var ix = find(k);
    if (ix > 0) rows[ix] = row; else rows.push(row);
  });
  if (rows.length > 1) writeSheetData(sh, headers, rows.slice(1));
  return jsonOk({ ok: true });
}

function parseRows(s) {
  if (s === undefined || s === null || s === '') return [];
  try {
    var a = JSON.parse(String(s));
    return Object.prototype.toString.call(a) === '[object Array]' ? a : [];
  } catch (err) { return []; }
}

function handleBackupQuery(body, auth) {
  var q = String(body.q || '').toLowerCase();
  var op = String(body.op || '');
  var from = String(body.from || '').slice(0, 10);
  var to = String(body.to || '').slice(0, 10);
  var limit = Math.min(parseInt(body.limit || 100, 10) || 100, 500);
  var sh = getSheet(SHEET_OPLOG);
  var rows = [];
  try { rows = readSheet(sh); } catch (err) { rows = []; }
  var out = [];
  for (var i = rows.length - 1; i >= 1; i--) {
    var r = rows[i] || [];
    if (!r[0]) continue;
    var rowDate = String(r[0] || '');
    var dayOnly = rowDate.slice(0, 10);
    if (from && dayOnly < from) continue;
    if (to && dayOnly > to) continue;
    if (op && String(r[2] || '') !== op) continue;
    if (q) {
      var hay = (rowDate + ' ' + String(r[1] || '') + ' ' + String(r[2] || '') + ' ' + String(r[3] || '')).toLowerCase();
      if (hay.indexOf(q) < 0) continue;
    }
    out.push({ ts: rowDate, user: String(r[1] || ''), op: String(r[2] || ''), data: String(r[3] || '') });
    if (out.length >= limit) break;
  }
  return jsonOk({ rows: out });
}

/**
 * ====== لوحة التحكم ======
 */
/**
 * ====== المصاريف (إيجار / مرتبات / …) ======
 */
function handleAddExpense(body, userCheck) {
  if (!hasPermission(userCheck, 'reports')) return jsonError('لا تملك صلاحية إضافة مصاريف');
  var id = body.id || ('X' + Date.now().toString().slice(-6));
  var dateStr = body.date || formatDate(new Date());
  addRow(getSheet(SHEET_EXPENSES), [id, dateStr, body.cashier || (userCheck.name || ''), body.type || 'أخرى', Number(body.amount) || 0, body.notes || '']);
  return jsonOk({ ok: true, id: id });
}

function handleGetExpenses(body, userCheck) {
  if (!hasPermission(userCheck, 'reports')) return jsonError('لا تملك صلاحية عرض المصاريف');
  var headers = ['id', 'date', 'cashier', 'type', 'amount', 'notes'];
  var rows = readSheet(getSheet(SHEET_EXPENSES));
  var expenses = rowsToObjects(rows, headers);
  expenses.forEach(function (e) { e.amount = Number(e.amount) || 0; });
  expenses.sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
  return jsonOk(expenses);
}

function handleDeleteExpense(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية حذف المصاريف');
  var id = String(body.id || '');
  if (!id) return jsonError('المعرّف مطلوب');
  var sh = getSheet(SHEET_EXPENSES);
  var rows = readSheet(sh);
  var found = false;
  for (var i = rows.length - 1; i >= 1; i--) {
    if (String(rows[i][0]) === id) { sh.deleteRow(i + 1); found = true; break; }
  }
  if (!found) return jsonOk({ ok: true, already: true });
  return jsonOk({ ok: true });
}

function handleGetDashboard() {
  var now = new Date();
  var from = startOfDay(now);
  var to = now;

  var salesSheet = getSheet(SHEET_SALES);
  var salesRows = readSheet(salesSheet);

  // المُرجع نقداً (استرجاع) يُخصم من مبيعات اليوم ليتماشى مع التقارير
  var retSheet = getSheet(SHEET_RETURNS);
  var retRows = readSheet(retSheet);
  var retByInv = {};
  for (var r = 1; r < retRows.length; r++) {
    if (!retRows[r]) continue;
    if (String(retRows[r][8] || '') !== 'استرجاع') continue;
    var inv = String(retRows[r][1] || '');
    if (!inv) continue;
    retByInv[inv] = (retByInv[inv] || 0) + (Number(retRows[r][6]) || 0);
  }

  var todayTotal = 0, todayCount = 0;
  for (var i = 1; i < salesRows.length; i++) {
    var d = new Date(salesRows[i][1]);
    if (d >= from && d <= to) {
      var st = String(salesRows[i][12] || 'مكتملة');
      if (st === 'مرجوع') continue;
      var amt = Number(salesRows[i][8]) || 0;
      if (st === 'استرجاع جزئي') amt -= (retByInv[String(salesRows[i][0])] || 0);
      todayTotal += Math.max(0, amt);
      todayCount++;
    }
  }

  var productSheet = getSheet(SHEET_PRODUCTS);
  var productRows = readSheet(productSheet);
  var productsCount = productRows.length - 1;
  var lowStock = [];
  for (var p = 1; p < productRows.length; p++) {
    if ((Number(productRows[p][8]) || 0) <= (Number(productRows[p][9]) || 0)) {
      lowStock.push({ name: productRows[p][1], quantity: Number(productRows[p][8]) || 0 });
    }
  }

  var custSheet = getSheet(SHEET_CUSTOMERS);
  var custRows = readSheet(custSheet);

  return jsonOk({
    todayTotal: todayTotal,
    todayCount: todayCount,
    productsCount: productsCount,
    lowStock: lowStock,
    customersCount: custRows.length - 1,
    lowStockCount: lowStock.length
  });
}

// مزامنة مرآة الشيت من pos-data الخاص بالجهاز: يُرسل البيانات التجارية فقط
// (بيانات التنفيذ اليومي) دون جدول المستخدمين، ويُسمح لأي دور مسجّل للدخول
// لأنه عملية مزامنة لبيانات الجهاز إلى الشيت (وليس استيراد نسخة احتياطية).
// مفتاح دمج صف في الجدول (أعمدة الهوية) أو محتوى الصف بالكامل عند عدم وجود هوية
function mirrorRowKey(keyCols, row) {
  if (keyCols) {
    var parts = [];
    for (var i = 0; i < keyCols.length; i++) {
      var idx = keyCols[i];
      parts.push(String(row[idx] !== undefined ? row[idx] : ''));
    }
    if (parts.join('').length === 0) return 'R:' + JSON.stringify(row);
    return parts.join('|');
  }
  return 'R:' + JSON.stringify(row);
}

// دمج بيانات الجهاز مع البيانات الموجودة بالشيت بدل الاستبدال الكامل:
// - أي صف موجود بالشيت وغير موجود لدى الجهاز يبقى كما هو (لا يُمسح).
// - أي صف بحاصل لدى الجهاز يستبدل نظيره في الشيت (الجهاز هو المرجع المحلي).
// بهذا لا تستطيع أي نسخة جديدة/فارغة من pos-data محو بيانات الشيت.
function mergeTable(sh, headers, incoming, keyCols) {
  incoming = incoming || [];
  var width = headers.length;
  var norm = function (r) {
    var row = (Array.isArray(r) ? r.slice(0, width) : []);
    while (row.length < width) row.push('');
    return row;
  };
  var existing = [];
  if (sh.getLastRow() >= 1) {
    var vals = sh.getRange(1, 1, sh.getLastRow(), sh.getLastColumn()).getValues();
    if (vals && vals.length > 1) existing = vals.slice(1);
  }
  var incMap = {};
  var incRows = [];
  incoming.forEach(function (r) {
    if (!Array.isArray(r)) return;
    var row = norm(r);
    incRows.push(row);
    incMap[mirrorRowKey(keyCols, row)] = row;
  });
  var outRows = [];
  var seen = {};
  existing.forEach(function (r) {
    var row = norm(r);
    var k = mirrorRowKey(keyCols, row);
    outRows.push((incMap.hasOwnProperty(k) && !seen[k]) ? incMap[k] : row);
    seen[k] = true;
  });
  incRows.forEach(function (row) {
    var k = mirrorRowKey(keyCols, row);
    if (!seen[k]) { outRows.push(row); seen[k] = true; }
  });
  clearSheet(sh);
  writeSheetData(sh, headers, outRows);
}

function handleSyncMirror(body, userCheck) {
  if (!userCheck.role) return jsonError('غير مصرح به');
  // key cols: أعمدة الهوية لكل جدول (بنود المبيعات/المشتريات = فاتورة + صنف، الدفعات بلا هوية)
  var keys = ['products', 'sales', 'saleItems', 'customers', 'creditDetails', 'payments', 'suppliers', 'supplierPayments', 'purchases', 'purchaseItems', 'purchaseReturns', 'returns', 'archive', 'expenses', 'settings'];
  var keyColsMap = {
    products: [0], sales: [0], saleItems: [0, 1], customers: [0], creditDetails: [0],
    payments: null, suppliers: [0], supplierPayments: [0], purchases: [0], purchaseItems: [0, 1],
    purchaseReturns: [0], returns: [0], archive: [0], expenses: [0], settings: [0]
  };
  var okTables = [], bad = [];
  keys.forEach(function (key) {
    try {
      var sh = (key === 'products') ? getSheet(SHEET_PRODUCTS) :
               (key === 'sales') ? getSheet(SHEET_SALES) :
               (key === 'saleItems') ? getSheet(SHEET_SALE_ITEMS) :
               (key === 'creditDetails') ? getSheet(SHEET_CREDIT_DETAILS) :
               (key === 'purchaseItems') ? getSheet(SHEET_PURCHASE_ITEMS) :
               (key === 'purchaseReturns') ? getSheet(SHEET_PURCHASE_RETURNS) :
               (key === 'payments') ? getSheet(SHEET_PAYMENTS) :
               (key === 'customers') ? getSheet(SHEET_CUSTOMERS) :
               (key === 'suppliers') ? getSheet(SHEET_SUPPLIERS) :
               (key === 'supplierPayments') ? getSheet(SHEET_SUPPLIER_PAYMENTS) :
               (key === 'purchases') ? getSheet(SHEET_PURCHASES) :
               (key === 'returns') ? getSheet(SHEET_RETURNS) :
               (key === 'archive') ? getSheet(SHEET_ARCHIVE) :
               (key === 'expenses') ? getSheet(SHEET_EXPENSES) : getSheet(SHEET_SETTINGS);
      var headers = BACKUP_HEADERS[key];
      if (!headers) return;
      var data = (body[key] !== undefined && body[key] !== null && Array.isArray(body[key])) ? body[key] : [];
      mergeTable(sh, headers, data, keyColsMap[key]);
      okTables.push(key);
    } catch (err) {
      bad.push(key);
    }
  });
  try {
    if (body.categories !== undefined && Array.isArray(body.categories)) {
      var catSheet = getSheet(SHEET_CATEGORIES);
      mergeTable(catSheet, ['اسم القسم'], body.categories.map(function (x) { return [String(x)]; }), [0]);
      okTables.push('categories');
    }
  } catch (err) {
    bad.push('categories');
  }
  return jsonOk({ ok: true, tables: okTables, failed: bad });
}

/**
 * ====== المستخدمون ======
 */
function handleGetUsers(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية عرض المستخدمين');
  var sh = getSheet(SHEET_USERS);
  var rows = readSheet(sh);
  var headers = ['name', 'password', 'role', 'permissions'];
  var users = rowsToObjects(rows, headers);
  users.forEach(function (u) { u.permissions = (u.permissions || '').split(','); });
  return jsonOk(users);
}

function handleAddUser(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية إدارة المستخدمين');
  var sh = getSheet(SHEET_USERS);
  var rows = readSheet(sh);
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === body.name) return jsonError('المستخدم موجود مسبقاً');
  }
  addRow(sh, [body.name, body.password, body.role || 'كاشير', (body.permissions || []).join(',')]);
  return jsonOk({ ok: true });
}

function handleUpdateUser(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية تعديل المستخدمين');
  var sh = getSheet(SHEET_USERS);
  var rows = readSheet(sh);
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] && rows[i][0].toString() === (body.name || '').toString()) {
      // منع تغيير نفسك بالخطأ يبقى لأمان المدير - يمكن تحديث كل شيء
      sh.getRange(i + 1, 2, 1, 3).setValues([[
        body.password || rows[i][1], body.role || rows[i][2], (body.permissions || []).join(',')
      ]]);
      return jsonOk({ ok: true });
    }
  }
  return jsonError('المستخدم غير موجود');
}

function handleDeleteUser(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية حذف المستخدمين');
  var sh = getSheet(SHEET_USERS);
  var rows = readSheet(sh);
  for (var i = rows.length - 1; i >= 1; i--) {
    if (rows[i][0] && rows[i][0].toString() === (body.name || '').toString()) {
      if (rows[i][0] === 'المدير') return jsonError('لا يمكن حذف حساب المدير الرئيسي');
      sh.deleteRow(i + 1);
    }
  }
  return jsonOk({ ok: true });
}

/**
 * ====== الإعدادات ======
 */
function handleGetSettings() {
  var sh = getSheet(SHEET_SETTINGS);
  var rows = readSheet(sh);
  var settings = {};
  for (var i = 1; i < rows.length; i++) {
    settings[rows[i][0]] = rows[i][1];
  }
  return jsonOk(settings);
}

function handleUpdateSettings(body, userCheck) {
  if (!hasPermission(userCheck, 'users')) return jsonError('لا تملك صلاحية تعديل الإعدادات');
  var sh = getSheet(SHEET_SETTINGS);
  var rows = readSheet(sh);
  var settings = body.settings || {};
  Object.keys(settings).forEach(function (key) {
    var found = false;
    for (var i = 1; i < rows.length; i++) {
      if (rows[i][0] === key) { sh.getRange(i + 1, 2).setValue(settings[key]); found = true; break; }
    }
    if (!found) addRow(sh, [key, settings[key]]);
  });
  return jsonOk({ ok: true });
}

function getSetting(key, def) {
  var sh = getSheet(SHEET_SETTINGS);
  var rows = readSheet(sh);
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] === key) return rows[i][1] !== undefined ? rows[i][1] : def;
  }
  return def;
}

/**
 * ====== أدوات التاريخ ======
 */
function formatDate(d) {
  return Utilities.formatDate(d, Session.getScriptTimeZone(), 'yyyy-MM-dd');
}

function formatDateTime(d) {
  return Utilities.formatDate(d, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
}

// يحوّل أي قيمة تاريخ إلى كائن Date (يدعم ISO / رقم تسلسلي Excel) أو null
function toDate(v) {
  if (v === null || v === undefined || v === '') return null;
  if (typeof v === 'number') {
    if (v > 60) { var epoch = new Date(1899, 11, 30); return new Date(epoch.getTime() + v * 86400000); }
    return new Date(v * 86400000);
  }
  var s = String(v).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
    var parts = s.slice(0, 10).split('-');
    return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  }
  var d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

// يحوّل أي قيمة تاريخ (نص ISO / رقم تسلسلي Excel / كائن Date) إلى نص yyyy-MM-dd
function dateKey(v) {
  var d = toDate(v);
  if (!d) return '';
  return Utilities.formatDate(d, Session.getScriptTimeZone(), 'yyyy-MM-dd');
}
function formatTime(d) {
  return Utilities.formatDate(d, Session.getScriptTimeZone(), 'HH:mm:ss');
}
function startOfDay(d) {
  var x = new Date(d); x.setHours(0, 0, 0, 0); return x;
}
function endOfDay(d) {
  var x = new Date(d); x.setHours(23, 59, 59, 999); return x;
}

// تفاصيل بيانات آجل/ضمان عميل محدد
function handleGetCreditDetails(body) {
  var cdSheet = getSheet(SHEET_CREDIT_DETAILS);
  var cdRows = readSheet(cdSheet);
  var cdHeaders = ['invoiceNo', 'customer', 'phone', 'address', 'idNumber', 'guarantorName', 'guarantorAddress', 'guarantorPhone', 'amount', 'date'];
  var name = body.customer || '';
  var results = [];
  for (var i = 1; i < cdRows.length; i++) {
    if (cdRows[i] && cdRows[i][1] && cdRows[i][1].toString() === name) {
      var row = {};
      for (var c = 0; c < cdHeaders.length; c++) row[cdHeaders[c]] = cdRows[i][c];
      results.push(row);
    }
  }
  return jsonOk(results);
}

// أدوات إدارية
function test() {
  Logger.log(setupSheets());
}
